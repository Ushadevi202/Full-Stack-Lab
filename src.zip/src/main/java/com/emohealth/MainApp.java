package com.emohealth;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.net.URL;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        System.out.println("=== EmoHealth Starting ===");

        URL fxmlUrl = getClass().getResource(
            "/com/emohealth/fxml/LoginView.fxml"
        );
        System.out.println("LoginView URL: " + fxmlUrl);

        URL cssUrl = getClass().getResource(
            "/com/emohealth/css/dark-theme.css"
        );
        System.out.println("CSS URL: " + cssUrl);

        URL mainUrl = getClass().getResource(
            "/com/emohealth/fxml/MainView.fxml"
        );
        System.out.println("MainView URL: " + mainUrl);

        if (fxmlUrl == null) {
            throw new RuntimeException("LoginView.fxml NOT FOUND");
        }

        FXMLLoader loader = new FXMLLoader(fxmlUrl);
        Scene scene = new Scene(loader.load(), 500, 700);

        if (cssUrl != null) {
            scene.getStylesheets().add(cssUrl.toExternalForm());
        }

        primaryStage.setTitle("EmotionDetection");
        primaryStage.setScene(scene);
        primaryStage.show();

        System.out.println("=== App started OK ===");
    }

    public static void main(String[] args) {
        launch(args);
    }
}