package com.emohealth.service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.function.Consumer;


public class GroqService {

    private static GroqService instance;

    private static final String API_KEY =
        "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";
    

    private static final String API_URL =
        "https://api.groq.com/openai/v1/chat/completions";

    private static final String MODEL = "llama-3.1-8b-instant";;

    private GroqService() {}

    public static GroqService getInstance() {
        if (instance == null) instance = new GroqService();
        return instance;
    }

    public boolean isAvailable() {
        return API_KEY != null && !API_KEY.isEmpty();
    }

    public void generateWellnessInsight(
            String emotion,
            double stressIndex,
            String userName,
            Consumer<String> onResult,
            Consumer<String> onError) {

        String prompt = buildPrompt(emotion, stressIndex, userName);

        new Thread(() -> {
            try {
                String body = """
                    {
                      "model": "%s",
                      "messages": [
                        {
                          "role": "system",
                          "content": "You are a compassionate mental wellness assistant. Give warm, empathetic, personalised advice. Keep responses under 150 words."
                        },
                        {
                          "role": "user",
                          "content": "%s"
                        }
                      ],
                      "temperature": 0.7,
                      "max_tokens": 200
                    }
                    """.formatted(
                    MODEL,
                    prompt.replace("\"", "'")
                          .replace("\n", " ")
                );

                HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(10))
                    .build();

                HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + API_KEY)
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .timeout(Duration.ofSeconds(30))
                    .build();

                HttpResponse<String> response = client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString()
                );

                String result = extractContent(response.body());

                if (result != null && !result.isEmpty()) {
                    javafx.application.Platform.runLater(() ->
                        onResult.accept(result.trim())
                    );
                } else {
                    javafx.application.Platform.runLater(() ->
                        onError.accept("Empty response from Groq")
                    );
                }

            } catch (Exception e) {
                System.err.println("Groq error: " + e.getMessage());
                javafx.application.Platform.runLater(() ->
                    onError.accept(e.getMessage())
                );
            }
        }).start();
    }

    private String buildPrompt(String emotion,
                                double stress,
                                String name) {
        return String.format(
            "A person named %s has just had their voice analysed. " +
            "Their detected emotion is '%s' with a stress index " +
            "of %.1f out of 10. " +
            "Write a warm, empathetic, personalised wellness message. " +
            "Include: 1) Brief acknowledgment of how they feel, " +
            "2) One specific breathing technique, " +
            "3) One actionable suggestion to improve their mood. " +
            "Keep it under 150 words. Be warm and supportive.",
            name, emotion, stress
        );
    }

    private String extractContent(String json) {
        try {
            String key = "\"content\":\"";
            int start = json.indexOf(key);
            if (start < 0) {
                key = "\"content\": \"";
                start = json.indexOf(key);
            }
            if (start < 0) return null;
            start += key.length();
            StringBuilder sb = new StringBuilder();
            for (int i = start; i < json.length(); i++) {
                char c = json.charAt(i);
                if (c == '"' && json.charAt(i - 1) != '\\') break;
                if (c == '\\' && i + 1 < json.length()) {
                    char next = json.charAt(i + 1);
                    if (next == 'n') { sb.append('\n'); i++; continue; }
                    if (next == '"') { sb.append('"'); i++; continue; }
                    if (next == '\\') { sb.append('\\'); i++; continue; }
                }
                sb.append(c);
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}