package com.emohealth.service;

public class OllamaService {

    private static OllamaService instance;

    private OllamaService() {}

    public static OllamaService getInstance() {
        if (instance == null) instance = new OllamaService();
        return instance;
    }

    public boolean isAvailable() {
        return false;
    }

    public void startOllamaIfNotRunning() {
        System.out.println("Ollama disabled — using Groq instead.");
    }
}