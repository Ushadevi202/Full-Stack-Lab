package com.emohealth.service;

import com.emohealth.config.EmailConfig;

import jakarta.mail.*;
import jakarta.mail.internet.*;

import java.util.Properties;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public class EmailService {

    private static EmailService instance;

    private EmailService() {}

    public static EmailService getInstance() {
        if (instance == null) instance = new EmailService();
        return instance;
    }

    // ── Generate 6-digit reset code ───────────────
    public String generateResetCode() {
        Random rng = new Random();
        int code = 100000 + rng.nextInt(900000);
        return String.valueOf(code);
    }

    // ── Send reset email asynchronously ───────────
    public void sendResetEmail(String toEmail, String userName,
                               String resetCode,
                               Consumer<Boolean> callback) {
        CompletableFuture.supplyAsync(() -> {
            try {
                Properties props = new Properties();
                props.put("mail.smtp.auth",            "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host",            EmailConfig.SMTP_HOST);
                props.put("mail.smtp.port",            EmailConfig.SMTP_PORT);
                props.put("mail.smtp.ssl.trust",       EmailConfig.SMTP_HOST);

                Session session = Session.getInstance(props,
                    new Authenticator() {
                        @Override
                        protected PasswordAuthentication
                                getPasswordAuthentication() {
                            return new PasswordAuthentication(
                                EmailConfig.SENDER_EMAIL,
                                EmailConfig.SENDER_PASSWORD
                            );
                        }
                    }
                );

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(
                    EmailConfig.SENDER_EMAIL,
                    EmailConfig.APP_NAME
                ));
                message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(toEmail)
                );
                message.setSubject(
                    "Reset your " + EmailConfig.APP_NAME + " password"
                );
                message.setContent(buildEmailBody(userName, resetCode),
                    "text/html; charset=utf-8");

                Transport.send(message);
                System.out.println("Reset email sent to: " + toEmail);
                return true;

            } catch (Exception e) {
                System.err.println("Email send failed: " + e.getMessage());
                return false;
            }
        }).thenAccept(result ->
            javafx.application.Platform.runLater(() -> callback.accept(result))
        );
    }

    // ── Welcome email ─────────────────────────────
    public void sendWelcomeEmail(String toEmail, String userName,
                                 String userId) {
        CompletableFuture.runAsync(() -> {
            try {
                Properties props = new Properties();
                props.put("mail.smtp.auth",            "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host",            EmailConfig.SMTP_HOST);
                props.put("mail.smtp.port",            EmailConfig.SMTP_PORT);
                props.put("mail.smtp.ssl.trust",       EmailConfig.SMTP_HOST);

                Session session = Session.getInstance(props,
                    new Authenticator() {
                        @Override
                        protected PasswordAuthentication
                                getPasswordAuthentication() {
                            return new PasswordAuthentication(
                                EmailConfig.SENDER_EMAIL,
                                EmailConfig.SENDER_PASSWORD
                            );
                        }
                    }
                );

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(
                    EmailConfig.SENDER_EMAIL,
                    EmailConfig.APP_NAME
                ));
                message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(toEmail)
                );
                message.setSubject(
                    "Welcome to " + EmailConfig.APP_NAME + "!"
                );
                message.setContent(
                    buildWelcomeBody(userName, userId),
                    "text/html; charset=utf-8"
                );
                Transport.send(message);
                System.out.println("Welcome email sent to: " + toEmail);
            } catch (Exception e) {
                System.err.println("Welcome email failed: " + e.getMessage());
            }
        });
    }

    // ── Email HTML templates ──────────────────────
    private String buildEmailBody(String name, String code) {
        return """
            <div style="font-family:Segoe UI,sans-serif;max-width:520px;
                        margin:0 auto;background:#F5F4F0;padding:32px;">
              <div style="background:white;border-radius:16px;
                          padding:36px;border:1px solid #DDD9D0;">
                <h2 style="color:#1A1A2E;font-size:22px;margin:0 0 8px;">
                  Reset your password
                </h2>
                <p style="color:#6B6B80;font-size:14px;margin:0 0 24px;">
                  Hi %s, use this code to reset your password.
                  It expires in 15 minutes.
                </p>
                <div style="background:#F0EEF8;border-radius:12px;
                            padding:24px;text-align:center;
                            border:1px solid #C8B8F0;margin:0 0 24px;">
                  <span style="font-size:36px;font-weight:bold;
                               letter-spacing:8px;color:#634ED2;">%s</span>
                </div>
                <p style="color:#9090A8;font-size:12px;margin:0;">
                  If you did not request this, please ignore this email.
                  Your password will not be changed.
                </p>
                <hr style="border:none;border-top:1px solid #E8E4E0;
                           margin:24px 0;">
                <p style="color:#B0B0C0;font-size:11px;margin:0;">
                  EmotionDetection &middot; Mental Health Monitor
                </p>
              </div>
            </div>
            """.formatted(name, code);
    }

    private String buildWelcomeBody(String name, String userId) {
        return """
            <div style="font-family:Segoe UI,sans-serif;max-width:520px;
                        margin:0 auto;background:#F5F4F0;padding:32px;">
              <div style="background:white;border-radius:16px;
                          padding:36px;border:1px solid #DDD9D0;">
                <h2 style="color:#1A1A2E;font-size:22px;margin:0 0 8px;">
                  Welcome to EmotionDetection!
                </h2>
                <p style="color:#6B6B80;font-size:14px;margin:0 0 16px;">
                  Hi %s, your account has been created successfully.
                </p>
                <p style="color:#6B6B80;font-size:14px;margin:0 0 24px;">
                  Your User ID is: <strong style="color:#634ED2;">%s</strong>
                </p>
                <p style="color:#3A3A52;font-size:14px;margin:0 0 8px;">
                  You can now:
                </p>
                <ul style="color:#6B6B80;font-size:14px;
                           padding-left:20px;margin:0 0 24px;">
                  <li>Record or upload your voice for emotion analysis</li>
                  <li>Track your emotional wellness over time</li>
                  <li>Get personalised AI health feedback</li>
                  <li>View your mood calendar and history</li>
                </ul>
                <p style="color:#9090A8;font-size:12px;margin:0;">
                  Your data is always private and never shared.
                </p>
                <hr style="border:none;border-top:1px solid #E8E4E0;
                           margin:24px 0;">
                <p style="color:#B0B0C0;font-size:11px;margin:0;">
                  EmotionDetection &middot; Mental Health Monitor
                </p>
              </div>
            </div>
            """.formatted(name, userId);
    }
}