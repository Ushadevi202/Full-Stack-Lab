package com.emohealth.service;

import com.emohealth.model.EmotionResult;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public class EmotionApiService {

    private static final String BASE_URL = "http://localhost:8080/api";

    public EmotionApiService() {
        System.out.println("EmotionApiService ready.");
    }

    public void analyseAsync(byte[] audioBytes, Consumer<EmotionResult> callback) {
        CompletableFuture.supplyAsync(() -> {
            try {
                if (audioBytes != null && audioBytes.length > 0) {
                    var client = java.net.http.HttpClient.newHttpClient();
                    var request = java.net.http.HttpRequest.newBuilder()
                        .uri(java.net.URI.create(BASE_URL + "/analyse"))
                        .header("Content-Type", "application/octet-stream")
                        .POST(java.net.http.HttpRequest.BodyPublishers
                            .ofByteArray(audioBytes))
                        .build();

                    var response = client.send(request,
                        java.net.http.HttpResponse.BodyHandlers.ofString());

                    if (response.statusCode() == 200) {
                        return parseSimpleJson(response.body());
                    }
                }
            } catch (Exception e) {
                System.out.println("Backend not available, using simulation.");
            }
            return EmotionResult.simulate();
        }).thenAccept(result ->
            javafx.application.Platform.runLater(() -> callback.accept(result))
        );
    }

    private EmotionResult parseSimpleJson(String json) {
        try {
            EmotionResult result = new EmotionResult();

            String dominant = extractValue(json, "dominantEmotion");
            result.setDominantEmotion(dominant.isEmpty() ? "Neutral" : dominant);

            String conf = extractValue(json, "confidence");
            result.setTopConfidence(conf.isEmpty() ? 0 : Integer.parseInt(conf));

            String stress = extractValue(json, "stressIndex");
            result.setStressIndex(stress.isEmpty() ? 0.0 : Double.parseDouble(stress));

            String insight = extractValue(json, "insight");
            result.setAiInsight(insight.isEmpty() ? "No insight." : insight);

            return result;
        } catch (Exception e) {
            return EmotionResult.simulate();
        }
    }

    private String extractValue(String json, String key) {
        try {
            String search = "\"" + key + "\"";
            int idx = json.indexOf(search);
            if (idx < 0) return "";
            int colon = json.indexOf(":", idx);
            if (colon < 0) return "";
            int start = json.indexOf("\"", colon);
            if (start < 0) return "";
            int end = json.indexOf("\"", start + 1);
            if (end < 0) return "";
            return json.substring(start + 1, end);
        } catch (Exception e) {
            return "";
        }
    }

    public CompletableFuture<String> generateReport(int sessionId) {
        return CompletableFuture.completedFuture("Report generated for session " + sessionId);
    }
}