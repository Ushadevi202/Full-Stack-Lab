package com.emohealth.service;

import javax.sound.sampled.*;
import java.io.ByteArrayOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AudioRecorderService {

    private static final AudioFormat FORMAT = new AudioFormat(
        44100f, 16, 1, true, false
    );

    private TargetDataLine microphone;
    private ByteArrayOutputStream buffer;
    private ExecutorService executor;
    private boolean running = false;

    public AudioRecorderService() {
        executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "audio-recorder");
            t.setDaemon(true);
            return t;
        });
    }

    public void startRecording() {
        try {
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
            if (!AudioSystem.isLineSupported(info)) {
                System.err.println("Microphone not supported on this system.");
                return;
            }
            microphone = (TargetDataLine) AudioSystem.getLine(info);
            microphone.open(FORMAT);
            microphone.start();
            buffer  = new ByteArrayOutputStream();
            running = true;

            executor.submit(() -> {
                byte[] chunk = new byte[4096];
                while (running) {
                    int bytesRead = microphone.read(chunk, 0, chunk.length);
                    if (bytesRead > 0) {
                        synchronized (this) {
                            buffer.write(chunk, 0, bytesRead);
                        }
                    }
                }
            });

            System.out.println("Recording started.");
        } catch (LineUnavailableException e) {
            System.err.println("Could not open microphone: " + e.getMessage());
        }
    }

    public void stopRecording() {
        running = false;
        if (microphone != null && microphone.isOpen()) {
            microphone.stop();
            microphone.close();
        }
        System.out.println("Recording stopped. Bytes captured: " +
            (buffer != null ? buffer.size() : 0));
    }

    /** Returns the last ~5 seconds of PCM audio as a byte array. */
    public synchronized byte[] getLatestChunk() {
        if (buffer == null) return new byte[0];
        byte[] all = buffer.toByteArray();
        // ~5 seconds at 44100 Hz, 16-bit mono = 441000 bytes
        int chunkSize = Math.min(441000, all.length);
        byte[] chunk = new byte[chunkSize];
        System.arraycopy(all, all.length - chunkSize, chunk, 0, chunkSize);
        // Reset buffer to keep memory usage low
        buffer.reset();
        return chunk;
    }

    public boolean isRecording() { return running; }
}
