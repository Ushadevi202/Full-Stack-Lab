package com.emohealth.service;

import com.emohealth.config.GoogleAuthConfig;

import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public class GoogleAuthService {

    private static GoogleAuthService instance;

    private GoogleAuthService() {}

    public static GoogleAuthService getInstance() {
        if (instance == null) instance = new GoogleAuthService();
        return instance;
    }

    // Build Google login URL
    public String buildAuthUrl() {
        return GoogleAuthConfig.AUTH_URL +
            "?client_id="     + encode(GoogleAuthConfig.CLIENT_ID) +
            "&redirect_uri="  + encode(GoogleAuthConfig.REDIRECT_URI) +
            "&response_type=" + encode("code") +
            "&scope="         + encode(GoogleAuthConfig.SCOPE) +
            "&access_type=offline" +
            "&prompt=consent";
    }

    // Start local server to catch redirect and get code automatically
    public void signInWithBrowser(
            Consumer<GoogleUser> onSuccess,
            Consumer<String>     onError) {

        new Thread(() -> {
            try {
                // Start local HTTP server on port 8888
                HttpServer server = HttpServer.create(
                    new InetSocketAddress(8888), 0
                );

                CompletableFuture<String> codeFuture =
                    new CompletableFuture<>();

                server.createContext("/callback", exchange -> {
                    String query = exchange.getRequestURI().getQuery();
                    String code  = null;

                    if (query != null) {
                        for (String param : query.split("&")) {
                            String[] kv = param.split("=");
                            if (kv.length == 2 &&
                                    kv[0].equals("code")) {
                                code = URLDecoder.decode(
                                    kv[1], StandardCharsets.UTF_8
                                );
                                break;
                            }
                        }
                    }

                    // Send success page to browser
                    String response = """
                        <html>
                        <head>
                          <style>
                            body {
                              font-family: Segoe UI, sans-serif;
                              display: flex;
                              align-items: center;
                              justify-content: center;
                              height: 100vh;
                              margin: 0;
                              background: #F0EEF8;
                            }
                            .card {
                              background: white;
                              border-radius: 16px;
                              padding: 48px;
                              text-align: center;
                              box-shadow: 0 4px 24px rgba(0,0,0,0.1);
                              max-width: 400px;
                            }
                            h2 { color: #634ED2; margin-bottom: 12px; }
                            p  { color: #6B6B80; font-size: 15px; }
                          </style>
                        </head>
                        <body>
                          <div class="card">
                            <h2>&#10003; Signed in successfully!</h2>
                            <p>You can close this browser tab and
                               return to EmotionDetection.</p>
                          </div>
                        </body>
                        </html>
                        """;

                    byte[] bytes = response.getBytes(
                        StandardCharsets.UTF_8
                    );
                    exchange.getResponseHeaders().set(
                        "Content-Type", "text/html; charset=utf-8"
                    );
                    exchange.sendResponseHeaders(200, bytes.length);
                    exchange.getResponseBody().write(bytes);
                    exchange.getResponseBody().close();

                    if (code != null) codeFuture.complete(code);
                    else codeFuture.completeExceptionally(
                        new Exception("No code in callback")
                    );
                });

                server.start();
                System.out.println("Local OAuth server started on port 8888");

                // Open browser
                javafx.application.Platform.runLater(() -> {
                    try {
                        new ProcessBuilder(
                            "cmd", "/c", "start",
                            buildAuthUrl()
                        ).start();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                });

                // Wait for code (max 3 minutes)
                String authCode = codeFuture.get(
                    3, java.util.concurrent.TimeUnit.MINUTES
                );
                server.stop(0);

                // Exchange code for user info
                exchangeCode(authCode, onSuccess, onError);

            } catch (java.util.concurrent.TimeoutException e) {
                javafx.application.Platform.runLater(() ->
                    onError.accept(
                        "Sign in timed out. Please try again."
                    )
                );
            } catch (Exception e) {
                javafx.application.Platform.runLater(() ->
                    onError.accept("Error: " + e.getMessage())
                );
            }
        }).start();
    }

    private void exchangeCode(String authCode,
                               Consumer<GoogleUser> onSuccess,
                               Consumer<String>     onError) {
        try {
            String tokenBody =
                "code="           + encode(authCode) +
                "&client_id="     + encode(GoogleAuthConfig.CLIENT_ID) +
                "&client_secret=" + encode(GoogleAuthConfig.CLIENT_SECRET) +
                "&redirect_uri="  + encode(GoogleAuthConfig.REDIRECT_URI) +
                "&grant_type=authorization_code";

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest tokenReq = HttpRequest.newBuilder()
                .uri(URI.create(GoogleAuthConfig.TOKEN_URL))
                .header("Content-Type",
                    "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(tokenBody))
                .build();

            HttpResponse<String> tokenRes = client.send(
                tokenReq, HttpResponse.BodyHandlers.ofString()
            );

            System.out.println("Token response: " + tokenRes.body());

            String accessToken = extractJson(
                tokenRes.body(), "access_token"
            );

            if (accessToken == null) {
                javafx.application.Platform.runLater(() ->
                    onError.accept(
                        "Failed to get access token. " +
                        "Check your Client ID and Secret."
                    )
                );
                return;
            }

            HttpRequest userReq = HttpRequest.newBuilder()
                .uri(URI.create(GoogleAuthConfig.USER_INFO_URL))
                .header("Authorization", "Bearer " + accessToken)
                .GET().build();

            HttpResponse<String> userRes = client.send(
                userReq, HttpResponse.BodyHandlers.ofString()
            );

            String name  = extractJson(userRes.body(), "name");
            String email = extractJson(userRes.body(), "email");
            String sub   = extractJson(userRes.body(), "sub");

            if (name == null || email == null) {
                javafx.application.Platform.runLater(() ->
                    onError.accept(
                        "Could not get user info from Google."
                    )
                );
                return;
            }

            GoogleUser user = new GoogleUser(name, email, sub);
            javafx.application.Platform.runLater(() ->
                onSuccess.accept(user)
            );

        } catch (Exception e) {
            javafx.application.Platform.runLater(() ->
                onError.accept("Sign in error: " + e.getMessage())
            );
        }
    }

    // Keep this for manual code entry fallback
    public void exchangeCodeForUser(String authCode,
                                    Consumer<GoogleUser> onSuccess,
                                    Consumer<String>     onError) {
        new Thread(() ->
            exchangeCode(authCode, onSuccess, onError)
        ).start();
    }

    private String extractJson(String json, String key) {
        try {
            String search = "\"" + key + "\"";
            int idx   = json.indexOf(search);
            if (idx < 0) return null;
            int colon = json.indexOf(":", idx);
            int start = json.indexOf("\"", colon);
            int end   = json.indexOf("\"", start + 1);
            return json.substring(start + 1, end);
        } catch (Exception e) { return null; }
    }

    private String encode(String val) {
        return URLEncoder.encode(val, StandardCharsets.UTF_8);
    }

    public static class GoogleUser {
        public final String name;
        public final String email;
        public final String googleId;

        public GoogleUser(String name, String email,
                          String googleId) {
            this.name     = name;
            this.email    = email;
            this.googleId = googleId;
        }
    }
}