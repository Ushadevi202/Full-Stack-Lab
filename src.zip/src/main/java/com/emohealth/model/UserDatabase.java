package com.emohealth.model;

import com.emohealth.config.DatabaseConfig;

import java.sql.*;
import java.time.LocalDateTime;

public class UserDatabase {

    private static UserDatabase instance;

    private UserDatabase() {}

    public static UserDatabase getInstance() {
        if (instance == null) instance = new UserDatabase();
        return instance;
    }

    // ── Check if user ID exists ───────────────────
    public boolean userIdExists(String userId) {
        try {
            Connection conn = DatabaseConfig.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT id FROM users WHERE user_id = ?"
            );
            ps.setString(1, userId.trim().toLowerCase());
            ResultSet rs = ps.executeQuery();
            boolean exists = rs.next();
            ps.close();
            return exists;
        } catch (SQLException e) {
            System.err.println("userIdExists error: " + e.getMessage());
            return false;
        }
    }

    // ── Check if email exists ─────────────────────
    public boolean emailExists(String email) {
        try {
            Connection conn = DatabaseConfig.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT id FROM users WHERE email = ?"
            );
            ps.setString(1, email.trim().toLowerCase());
            ResultSet rs = ps.executeQuery();
            boolean exists = rs.next();
            ps.close();
            return exists;
        } catch (SQLException e) {
            System.err.println("emailExists error: " + e.getMessage());
            return false;
        }
    }

    // ── Register new user ─────────────────────────
    public boolean register(String name, String userId,
                            String email, String password) {
        try {
            Connection conn = DatabaseConfig.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO users (name, user_id, email, password) " +
                "VALUES (?, ?, ?, ?)"
            );
            ps.setString(1, name.trim());
            ps.setString(2, userId.trim().toLowerCase());
            ps.setString(3, email.trim().toLowerCase());
            ps.setString(4, password);
            int rows = ps.executeUpdate();
            ps.close();
            System.out.println("Registered: " + name + " / " + userId);
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("register error: " + e.getMessage());
            return false;
        }
    }

    // ── Sign in ───────────────────────────────────
    public RegisteredUser signIn(String userId, String password) {
        try {
            Connection conn = DatabaseConfig.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT name, user_id, email FROM users " +
                "WHERE user_id = ? AND password = ?"
            );
            ps.setString(1, userId.trim().toLowerCase());
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                RegisteredUser user = new RegisteredUser(
                    rs.getString("name"),
                    rs.getString("user_id"),
                    rs.getString("email"),
                    password
                );
                ps.close();
                return user;
            }
            ps.close();
            return null;
        } catch (SQLException e) {
            System.err.println("signIn error: " + e.getMessage());
            return null;
        }
    }

    // ── Find user by email ────────────────────────
    public RegisteredUser findByEmail(String email) {
        try {
            Connection conn = DatabaseConfig.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT name, user_id, email FROM users WHERE email = ?"
            );
            ps.setString(1, email.trim().toLowerCase());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                RegisteredUser user = new RegisteredUser(
                    rs.getString("name"),
                    rs.getString("user_id"),
                    rs.getString("email"),
                    ""
                );
                ps.close();
                return user;
            }
            ps.close();
            return null;
        } catch (SQLException e) {
            System.err.println("findByEmail error: " + e.getMessage());
            return null;
        }
    }

    // ── Save reset code ───────────────────────────
    public boolean saveResetCode(String email, String code) {
        try {
            Connection conn = DatabaseConfig.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE users SET reset_code = ?, reset_expiry = ? " +
                "WHERE email = ?"
            );
            ps.setString(1, code);
            ps.setTimestamp(2, Timestamp.valueOf(
                LocalDateTime.now().plusMinutes(15)
            ));
            ps.setString(3, email.trim().toLowerCase());
            int rows = ps.executeUpdate();
            ps.close();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("saveResetCode error: " + e.getMessage());
            return false;
        }
    }

    // ── Verify reset code ─────────────────────────
    public boolean verifyResetCode(String email, String code) {
        try {
            Connection conn = DatabaseConfig.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT id FROM users WHERE email = ? " +
                "AND reset_code = ? AND reset_expiry > NOW()"
            );
            ps.setString(1, email.trim().toLowerCase());
            ps.setString(2, code.trim());
            ResultSet rs = ps.executeQuery();
            boolean valid = rs.next();
            ps.close();
            return valid;
        } catch (SQLException e) {
            System.err.println("verifyResetCode error: " + e.getMessage());
            return false;
        }
    }

    // ── Update password ───────────────────────────
    public boolean updatePassword(String email, String newPassword) {
        try {
            Connection conn = DatabaseConfig.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE users SET password = ?, " +
                "reset_code = NULL, reset_expiry = NULL " +
                "WHERE email = ?"
            );
            ps.setString(1, newPassword);
            ps.setString(2, email.trim().toLowerCase());
            int rows = ps.executeUpdate();
            ps.close();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("updatePassword error: " + e.getMessage());
            return false;
        }
    }

    // ── Registered user record ────────────────────
    public static class RegisteredUser {
        private final String name;
        private final String userId;
        private final String email;
        private final String password;

        public RegisteredUser(String name, String userId,
                              String email, String password) {
            this.name     = name;
            this.userId   = userId;
            this.email    = email;
            this.password = password;
        }

        public String getName()     { return name;     }
        public String getUserId()   { return userId;   }
        public String getEmail()    { return email;    }
        public String getPassword() { return password; }

        public String getInitials() {
            if (name == null || name.isEmpty()) return "?";
            String[] parts = name.trim().split("\\s+");
            if (parts.length == 1)
                return parts[0].substring(0, 1).toUpperCase();
            return (parts[0].substring(0, 1) +
                    parts[parts.length - 1].substring(0, 1)).toUpperCase();
        }
    }
}