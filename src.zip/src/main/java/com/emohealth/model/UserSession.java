package com.emohealth.model;

public class UserSession {

    private static UserSession instance;
    private String userName;
    private String patientId;
    private String email;

    private UserSession() {}

    public static UserSession getInstance() {
        if (instance == null) instance = new UserSession();
        return instance;
    }

    public String getUserName()  { return userName;  }
    public String getPatientId() { return patientId; }
    public String getEmail()     { return email;     }

    public void setUserName(String n)  { this.userName  = n;  }
    public void setPatientId(String id){ this.patientId = id; }
    public void setEmail(String e)     { this.email     = e;  }

    public String getInitials() {
        if (userName == null || userName.isEmpty()) return "?";
        String[] parts = userName.trim().split("\\s+");
        if (parts.length == 1)
            return parts[0].substring(0, 1).toUpperCase();
        return (parts[0].substring(0, 1) +
                parts[parts.length - 1].substring(0, 1)).toUpperCase();
    }

    public void clear() {
        userName = null;
        patientId = null;
        email = null;
    }
}