package com.emohealth.model;

import java.time.LocalDateTime;

public class SessionRecord {

    private int id;
    private int patientId;
    private String patientName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private int segmentsAnalysed;
    private String dominantEmotion;
    private double stressIndex;
    private String aiReport;

    public SessionRecord() {}

    public SessionRecord(int patientId, String patientName) {
        this.patientId   = patientId;
        this.patientName = patientName;
        this.startTime   = LocalDateTime.now();
    }

    public void end() {
        this.endTime = LocalDateTime.now();
    }

    public long getDurationSeconds() {
        if (startTime == null || endTime == null) return 0;
        return java.time.Duration.between(startTime, endTime).getSeconds();
    }

    // ── Getters & Setters ──────────────────────────────────────────
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public String getPatientName() { return patientName; }
    public void setPatientName(String patientName) { this.patientName = patientName; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public int getSegmentsAnalysed() { return segmentsAnalysed; }
    public void setSegmentsAnalysed(int segmentsAnalysed) { this.segmentsAnalysed = segmentsAnalysed; }

    public String getDominantEmotion() { return dominantEmotion; }
    public void setDominantEmotion(String dominantEmotion) { this.dominantEmotion = dominantEmotion; }

    public double getStressIndex() { return stressIndex; }
    public void setStressIndex(double stressIndex) { this.stressIndex = stressIndex; }

    public String getAiReport() { return aiReport; }
    public void setAiReport(String aiReport) { this.aiReport = aiReport; }
}