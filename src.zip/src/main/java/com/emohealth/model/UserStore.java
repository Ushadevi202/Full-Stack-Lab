package com.emohealth.model;

import java.util.HashMap;
import java.util.Map;

public class UserStore {

    private static UserStore instance;

    // key = userId lowercase → RegisteredUser
    private final Map<String, RegisteredUser> users = new HashMap<>();

    private UserStore() {
        System.out.println("UserStore created — ready for registrations.");
    }

    public static UserStore getInstance() {
        if (instance == null) {
            instance = new UserStore();
        }
        return instance;
    }

    // Check if a userId is already registered
    public boolean userIdExists(String userId) {
        if (userId == null || userId.trim().isEmpty()) return false;
        boolean exists = users.containsKey(userId.toLowerCase().trim());
        System.out.println("userIdExists('" + userId + "') = " + exists);
        return exists;
    }

    // Register a new user — returns false if ID already taken
    public boolean register(String name, String userId, String password) {
        if (userId == null || userId.trim().isEmpty()) return false;
        String key = userId.toLowerCase().trim();
        if (users.containsKey(key)) {
            System.out.println("Register FAILED — userId already taken: " + key);
            return false;
        }
        users.put(key, new RegisteredUser(name, userId, password));
        System.out.println("Registered new user: " + name + " / " + userId);
        System.out.println("Total users: " + users.size());
        return true;
    }

    // Sign in — returns null if not found or wrong password
    public RegisteredUser signIn(String userId, String password) {
        if (userId == null || userId.trim().isEmpty()) return null;
        String key = userId.toLowerCase().trim();
        RegisteredUser user = users.get(key);
        if (user == null) {
            System.out.println("SignIn FAILED — user not found: " + key);
            return null;
        }
        if (!user.getPassword().equals(password)) {
            System.out.println("SignIn FAILED — wrong password for: " + key);
            return null;
        }
        System.out.println("SignIn SUCCESS: " + user.getName());
        return user;
    }

    public int getUserCount() {
        return users.size();
    }

    // ── Registered user record ────────────────────
    public static class RegisteredUser {
        private final String name;
        private final String userId;
        private final String password;

        public RegisteredUser(String name, String userId, String password) {
            this.name     = name;
            this.userId   = userId;
            this.password = password;
        }

        public String getName()     { return name;     }
        public String getUserId()   { return userId;   }
        public String getPassword() { return password; }

        public String getInitials() {
            if (name == null || name.isEmpty()) return "?";
            String[] parts = name.trim().split("\\s+");
            if (parts.length == 1)
                return parts[0].substring(0, 1).toUpperCase();
            return (parts[0].substring(0, 1) +
                    parts[parts.length - 1].substring(0, 1))
                    .toUpperCase();
        }
    }
}