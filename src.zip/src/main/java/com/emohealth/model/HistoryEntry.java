package com.emohealth.model;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class HistoryEntry {
    private String ownerUserId;
    private LocalDateTime dateTime;
    private String emotion;
    private int    confidence;
    private double stressIndex;
    private String aiFeedback;
    private String suggestions;
    private String breathingSteps;
    private String motivationalQuote;
    private String quoteAuthor;
    private List<String> resourceLinks;

    public HistoryEntry(String ownerUserId,String emotion, int confidence,
                        double stressIndex, String aiFeedback,
                        String suggestions) {
        this.ownerUserId = ownerUserId;
        this.dateTime        = LocalDateTime.now();
        this.emotion         = emotion;
        this.confidence      = confidence;
        this.stressIndex     = stressIndex;
        this.aiFeedback      = aiFeedback;
        this.suggestions     = suggestions;
        this.breathingSteps  = buildBreathingSteps(emotion);
        this.motivationalQuote = buildQuote(emotion)[0];
        this.quoteAuthor       = buildQuote(emotion)[1];
        this.resourceLinks     = buildResources(emotion);
    }
    public String getOwnerUserId() { return ownerUserId; }

    public String getFormattedDateTime() {
        return dateTime.format(DateTimeFormatter.ofPattern("dd MMM yyyy  h:mm a"));
    }
    public LocalDateTime getDateTime() { return dateTime; }
    public int getDay()   { return dateTime.getDayOfMonth(); }
    public int getMonth() { return dateTime.getMonthValue(); }
    public int getYear()  { return dateTime.getYear(); }

    public static String buildFeedback(String emotion, double stress) {
        return switch (emotion) {
            case "Happy" ->
                "You sound genuinely positive and full of energy today! " +
                "That warmth in your voice is clear and uplifting. " +
                "This is a wonderful moment to celebrate, connect with " +
                "others, or channel your energy into something meaningful.";
            case "Sad" ->
                "It sounds like you are carrying some sadness today. " +
                "That is completely valid and deeply human. " +
                "You do not have to push it away or pretend. " +
                "Acknowledging how you feel is the first and most important step.";
            case "Surprise" ->
                "Something seems to have caught you off guard today. " +
                "Unexpected moments can send a wave of mixed emotions through us. " +
                "It is okay to feel unsettled — give yourself a moment to breathe and process.";
            case "Angry" ->
                "Your voice reflects frustration and strong emotion — " +
                "that energy is real and valid. Anger often signals that " +
                "something important to you has been crossed. " +
                "Giving yourself space to process before reacting can help.";
            case "Fear" ->
                "Your voice shows signs of fear or worry right now. " +
                "Fear is your mind's way of trying to keep you safe, " +
                "but sometimes it can feel overwhelming. " +
                "Grounding yourself in the present moment can bring relief.";
            case "Neutral" ->
                "You sound calm, grounded and steady right now. " +
                "A balanced emotional state is a wonderful foundation. " +
                "Use this clarity to reflect, plan, " +
                "or simply appreciate the stillness around you.";
            case "Disgust" ->
                "Your voice reflects strong discomfort or aversion. " +
                "Disgust often arises when something feels deeply wrong " +
                "or goes against your values. " +
                "It is okay to step away from what is bothering you and reset.";
            default ->
                "We have analysed your voice. Stress level: " +
                String.format("%.1f", stress) + " / 10. " +
                "Checking in with yourself like this is already a powerful act.";
        };
    }

    public static String buildSuggestion(String emotion) {
        return switch (emotion) {
            case "Happy" ->
                "Use this great energy! Reach out to someone you care about, " +
                "start something creative, or write down what is going well " +
                "so you can look back on it on harder days.";
            case "Sad" ->
                "Step outside for even 5 minutes if you can. " +
                "Sunlight and gentle movement naturally lift low moods. " +
                "Also consider texting one person you trust — connection heals.";
            case "Surprise" ->
                "Journal for 5 minutes about what surprised you. " +
                "Write what happened, how it made you feel, and what you " +
                "need right now. Writing helps your brain process the unexpected.";
            case "Angry" ->
                "Splash cold water on your face or hold your wrists under " +
                "cold water for 30 seconds. Then write down what is bothering " +
                "you — getting it out of your head and onto paper brings relief.";
            case "Fear" ->
                "Try the 5-4-3-2-1 grounding technique: name 5 things you " +
                "can see, 4 you can touch, 3 you can hear, 2 you can smell, " +
                "1 you can taste. This brings you back to the present moment.";
            case "Neutral" ->
                "A calm mind is a gift. Try a 5-minute body scan — close your " +
                "eyes, notice each part of your body from head to toe with " +
                "curiosity and zero judgment.";
            case "Disgust" ->
                "Distance yourself from the source of discomfort if possible. " +
                "Take 3 slow deep breaths and do something that brings you " +
                "comfort — a favourite song, a warm drink, or a short walk.";
            default ->
                "Drink a glass of water, take 3 slow deep breaths, " +
                "and remember that reaching out for support is always a strength.";
        };
    }

    public static String buildBreathingSteps(String emotion) {
        return switch (emotion) {
            case "Angry", "Fear" ->
                "4-7-8 Breathing:\n" +
                "① Breathe IN through your nose for 4 seconds\n" +
                "② HOLD your breath for 7 seconds\n" +
                "③ Breathe OUT through your mouth for 8 seconds\n" +
                "④ Repeat 3 to 4 times\n\n" +
                "This activates your parasympathetic nervous system " +
                "and signals safety to your body.";
            case "Sad", "Disgust" ->
                "Energising Breath:\n" +
                "① Take a slow deep breath IN for 4 seconds\n" +
                "② HOLD for 2 seconds\n" +
                "③ Exhale gently for 4 seconds\n" +
                "④ Repeat 5 times then do a light stretch\n\n" +
                "Movement and breath together gently lift low energy.";
            case "Surprise" ->
                "Grounding Breath:\n" +
                "① Breathe IN slowly for 5 seconds\n" +
                "② HOLD for 3 seconds\n" +
                "③ Breathe OUT slowly for 6 seconds\n" +
                "④ Repeat until you feel settled\n\n" +
                "This helps your body come back to the present moment.";
            default ->
                "Box Breathing:\n" +
                "① Breathe IN for 4 seconds\n" +
                "② HOLD for 4 seconds\n" +
                "③ Breathe OUT for 4 seconds\n" +
                "④ HOLD for 4 seconds\n" +
                "⑤ Repeat 4 times\n\n" +
                "Simple box breathing keeps you centred and calm.";
        };
    }

    public static String[] buildQuote(String emotion) {
        return switch (emotion) {
            case "Happy" -> new String[]{
                "\"Happiness is not something ready-made. " +
                "It comes from your own actions.\"",
                "— Dalai Lama"
            };
            case "Sad" -> new String[]{
                "\"Even the darkest night will end and the sun will rise.\"",
                "— Victor Hugo"
            };
            case "Angry" -> new String[]{
                "\"For every minute you remain angry, " +
                "you give up sixty seconds of peace of mind.\"",
                "— Ralph Waldo Emerson"
            };
            case "Fear" -> new String[]{
                "\"You gain strength, courage and confidence by every " +
                "experience in which you really stop to look fear in the face.\"",
                "— Eleanor Roosevelt"
            };
            case "Neutral" -> new String[]{
                "\"Peace is the result of retraining your mind " +
                "to process life as it is, rather than as you think it should be.\"",
                "— Wayne Dyer"
            };
            case "Surprise" -> new String[]{
                "\"Life is what happens when you're busy making other plans.\"",
                "— John Lennon"
            };
            case "Disgust" -> new String[]{
                "\"You cannot always control what goes on outside, " +
                "but you can always control what goes on inside.\"",
                "— Wayne Dyer"
            };
            default -> new String[]{
                "\"You are stronger than you think, braver than you believe.\"",
                "— A.A. Milne"
            };
        };
    }

    public static List<String> buildResources(String emotion) {
        return switch (emotion) {
            case "Angry", "Fear", "Disgust" -> List.of(
                "iCall Helpline (India): 9152987821",
                "Vandrevala Foundation: 1860-2662-345 (24x7)",
                "NIMHANS: nimhans.ac.in — Free mental health resources",
                "MindShift CBT App — Free anxiety and anger management tool"
            );
            case "Sad" -> List.of(
                "iCall Helpline (India): 9152987821",
                "Snehi helpline: 044-24640050",
                "iCall Online: icallhelpline.org",
                "7 Cups App — Free online emotional support chat"
            );
            default -> List.of(
                "iCall Helpline (India): 9152987821",
                "NIMHANS Digital Academy: nimhansdigitalacademy.in",
                "Headspace App — Guided meditation and mindfulness",
                "Calm App — Sleep, relaxation and stress relief"
            );
        };
    }

    public static HistoryEntry withDate(LocalDateTime dt, String userId,
                                        String emotion,int conf, 
                                        double stress) {
        HistoryEntry e = new HistoryEntry(
            userId,emotion, conf, stress,
            buildFeedback(emotion, stress),
            buildSuggestion(emotion)
        );
        e.dateTime = dt;
        return e;
    }

    public String getEmotion()            { return emotion;           }
    public int    getConfidence()         { return confidence;        }
    public double getStressIndex()        { return stressIndex;       }
    public String getAiFeedback()         { return aiFeedback;        }
    public String getSuggestions()        { return suggestions;       }
    public String getBreathingSteps()     { return breathingSteps;    }
    public String getMotivationalQuote()  { return motivationalQuote; }
    public String getQuoteAuthor()        { return quoteAuthor;       }
    public List<String> getResourceLinks(){ return resourceLinks;     }
}