package com.emohealth.model;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class EmotionResult {

    //private static final String[] EMOTIONS={"Happy","Sad","Surprise","Angry","Fear","Neutral","Disgust"};

    private String dominantEmotion;
    private int topConfidence;
    private double stressIndex;
    private Map<String, Integer> scores;
    private String aiInsight;
    private List<String> tags;
    private LocalDateTime timestamp;

    public EmotionResult() {
        this.timestamp = LocalDateTime.now();
        this.scores = new LinkedHashMap<>();
    }

    // ── Builder-style factory ──────────────────────────────────────
    public static EmotionResult simulate() {
        EmotionResult r = new EmotionResult();
        java.util.Random rng = new java.util.Random();

        String[] emotions = {"Happy", "Sad", "Angry", "Fear", "Neutral", "Disgust", "Surprise"};
        int[]    baseScores = {9,42,5,18,15,30,8};

        // Shuffle to simulate variation
        int shift = rng.nextInt(emotions.length);
        for (int i = 0; i < emotions.length; i++) {
            int idx   = (i + shift) % emotions.length;
            int score = Math.max(0, Math.min(100,
                baseScores[idx] + rng.nextInt(20) - 10));
            r.scores.put(emotions[i], score);
        }

        // Find dominant
        r.dominantEmotion = r.scores.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey)
            .orElse("Neutral");
        r.topConfidence = r.scores.get(r.dominantEmotion);
        r.stressIndex   = 3.0 + rng.nextDouble() * 6.0;

        r.aiInsight = buildInsight(r.dominantEmotion, r.stressIndex);
        r.tags      = buildTags(r.dominantEmotion, r.stressIndex);

        return r;
    }

    private static String buildInsight(String emotion, double stress) {
        return switch (emotion) {
            case "Fear" ->
                "Fear and anxiety detected in your voice. " +
                "Voice pitch variance is above baseline. " +
                "Calming techniques are recommended.";
            case "Sad" ->
                "Sadness detected. Low energy vocal patterns " +
                "with reduced speech rate. " +
                "Consider supportive activities.";
            case "Angry" ->
                "Frustration and heightened arousal detected. " +
                "Vocal intensity is elevated. " +
                "Take a moment to breathe and settle.";
            case "Happy" ->
                "Positive emotional state detected. " +
                "Good energy and engagement in your voice. " +
                "Great time for meaningful activities!";
            case "Disgust" ->
                "Strong discomfort detected in your voice. " +
                "Something may be bothering you deeply. " +
                "Step away and reset with a calming activity.";
            case "Surprise" ->
                "Unexpected emotional shift detected. " +
                "Your voice shows signs of being caught off guard. " +
                "Take a moment to process what happened.";
            case "Neutral" ->
                "Calm and balanced emotional state detected. " +
                "No significant stress markers in your voice. " +
                "A good time to reflect or plan ahead.";
            default ->
                String.format(
                    "Stress index: %.1f/10. " +
                    "Emotional state: %s. " +
                    "Continue monitoring.",
                    stress, emotion.toLowerCase()
                );
        };
    }

    private static List<String> buildTags(String emotion,
                                            double stress) {
        List<String> tags = new java.util.ArrayList<>();
        if (stress > 6) tags.add("High stress");
        if (stress > 4) tags.add("Monitor closely");
        if ("Fear".equals(emotion) ||
            "Angry".equals(emotion))  tags.add("Breathing exercise");
        if ("Sad".equals(emotion))    tags.add("Supportive care");
        if ("Happy".equals(emotion))  tags.add("Positive state");
        if ("Disgust".equals(emotion))tags.add("Take a break");
        if ("Surprise".equals(emotion))tags.add("Process emotions");
        if ("Neutral".equals(emotion))tags.add("Stable");
        if (tags.isEmpty())           tags.add("Stable");
        return tags;
    }

    // ── Getters & Setters ──────────────────────────────────────────
    public String getDominantEmotion() { return dominantEmotion; }
    public void setDominantEmotion(String dominantEmotion) { this.dominantEmotion = dominantEmotion; }

    public int getTopConfidence() { return topConfidence; }
    public void setTopConfidence(int topConfidence) { this.topConfidence = topConfidence; }

    public double getStressIndex() { return stressIndex; }
    public void setStressIndex(double stressIndex) { this.stressIndex = stressIndex; }

    public Map<String, Integer> getScores() { return scores; }
    public void setScores(Map<String, Integer> scores) { this.scores = scores; }

    public String getAiInsight() { return aiInsight; }
    public void setAiInsight(String aiInsight) { this.aiInsight = aiInsight; }

    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
