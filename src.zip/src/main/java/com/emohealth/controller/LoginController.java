package com.emohealth.controller;

import com.emohealth.model.UserDatabase;
import com.emohealth.model.UserDatabase.RegisteredUser;
import com.emohealth.model.UserSession;
import com.emohealth.service.EmailService;
import com.emohealth.service.GoogleAuthService;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

public class LoginController implements Initializable {

    @FXML private Label         cardHeading;
    @FXML private Label         cardSubHeading;
    @FXML private VBox          nameRow;
    @FXML private TextField     signUpNameField;
    @FXML private TextField     userIdField;
    @FXML private Label         idAvailableLabel;
    @FXML private VBox          emailRow;
    @FXML private TextField     emailField;
    @FXML private Label         emailValidLabel;
    @FXML private PasswordField passwordField;
    @FXML private VBox          confirmRow;
    @FXML private PasswordField confirmField;
    @FXML private HBox          forgotRow;
    @FXML private Label         errorLabel;
    @FXML private Label         successLabel;
    @FXML private Button        mainButton;
    @FXML private Label         switchLabel;
    @FXML private Button        switchButton;
    @FXML private Button        googleBtn;

    private boolean isSignInMode = true;

    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
    );

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        clearMessages();

        // Live User ID check
        userIdField.textProperty().addListener((obs, o, newVal) -> {
            if (isSignInMode || newVal == null || newVal.trim().isEmpty()) {
                idAvailableLabel.setText(""); return;
            }
            String val = newVal.trim();
            if (val.length() < 4) {
                setLabel(idAvailableLabel, "At least 4 characters needed", false);
                return;
            }
            if (val.contains(" ")) {
                setLabel(idAvailableLabel, "No spaces allowed", false);
                return;
            }
            boolean exists = UserDatabase.getInstance().userIdExists(val);
            setLabel(idAvailableLabel,
                exists ? "✗  Already taken" : "✓  Available", !exists);
        });

        // Live email validation
        emailField.textProperty().addListener((obs, o, newVal) -> {
            if (isSignInMode || newVal == null || newVal.trim().isEmpty()) {
                emailValidLabel.setText(""); return;
            }
            boolean valid = EMAIL_PATTERN.matcher(newVal.trim()).matches();
            setLabel(emailValidLabel,
                valid ? "✓  Valid email" : "✗  Enter a valid email address",
                valid);
        });
    }

    // ── Switch sign in / sign up ──────────────────
    @FXML
    private void onSwitchMode() {
        isSignInMode = !isSignInMode;
        clearMessages();
        clearFields();

        if (isSignInMode) {
            cardHeading.setText("Welcome back");
            cardSubHeading.setText("Sign in to continue your wellness journey");
            mainButton.setText("Sign in");
            switchLabel.setText("New here?");
            switchButton.setText("Create an account");
            userIdField.setPromptText("Enter your user ID");
            nameRow.setVisible(false);  nameRow.setManaged(false);
            emailRow.setVisible(false); emailRow.setManaged(false);
            confirmRow.setVisible(false); confirmRow.setManaged(false);
            forgotRow.setVisible(true); forgotRow.setManaged(true);
        } else {
            cardHeading.setText("Create your account");
            cardSubHeading.setText("Free, private and takes 30 seconds");
            mainButton.setText("Create account");
            switchLabel.setText("Already have an account?");
            switchButton.setText("Sign in instead");
            userIdField.setPromptText("Choose a user ID  (min 4 chars, no spaces)");
            nameRow.setVisible(true);   nameRow.setManaged(true);
            emailRow.setVisible(true);  emailRow.setManaged(true);
            confirmRow.setVisible(true); confirmRow.setManaged(true);
            forgotRow.setVisible(false); forgotRow.setManaged(false);
        }
    }

    // ── Main action ───────────────────────────────
    @FXML
    private void onMainAction() {
        clearMessages();
        if (isSignInMode) doSignIn(); else doSignUp();
    }

    // ── Google Sign In (UI only) ──────────────────
    @FXML
    private void onGoogleSignIn() {
        Stage authStage = new Stage();
        authStage.initModality(Modality.APPLICATION_MODAL);
        authStage.setTitle("Sign in with Google");
        authStage.setResizable(false);

        // ── Header ────────────────────────────────────
        VBox header = new VBox(6);
        header.setStyle(
            "-fx-background-color:#F8F7F4;" +
            "-fx-padding:24 28 20 28;" +
            "-fx-border-color:#E8E4E0;" +
            "-fx-border-width:0 0 1 0;"
        );

        Label title = new Label("Sign in with Google");
        title.setStyle(
            "-fx-font-size:20px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:#1A1A2E;"
        );

        Label sub = new Label(
            "Use your Google account to sign in to EmotionDetection"
        );
        sub.setStyle(
            "-fx-font-size:13px;" +
            "-fx-text-fill:#6B6B80;"
        );
        header.getChildren().addAll(title, sub);

        // ── Steps ─────────────────────────────────────
        VBox stepsBox = new VBox(10);
        stepsBox.setStyle(
            "-fx-background-color:#F0EEF8;" +
            "-fx-border-color:#C8B8F0;" +
            "-fx-border-width:1;" +
            "-fx-border-radius:10px;" +
            "-fx-background-radius:10px;" +
            "-fx-padding:16;"
        );

        String[] steps = {
            "① Click  Open Google Sign In  below",
            "② Sign in with your Google account in the browser",
            "③ Copy the authorisation code shown by Google",
            "④ Paste the code below and click Continue"
        };

        for (String step : steps) {
            Label s = new Label(step);
            s.setStyle(
                "-fx-font-size:13px;" +
                "-fx-text-fill:#3A2E7A;" +
                "-fx-line-spacing:2;"
            );
            stepsBox.getChildren().add(s);
        }

        // ── Open browser button ────────────────────────
        String authUrl = GoogleAuthService.getInstance().buildAuthUrl();

        Button openBtn = new Button("🔵   Open Google Sign In");
        openBtn.setMaxWidth(Double.MAX_VALUE);
        openBtn.setStyle(
            "-fx-background-color:#4285F4;" +
            "-fx-text-fill:white;" +
            "-fx-font-size:14px;" +
            "-fx-font-weight:bold;" +
            "-fx-border-radius:10px;" +
            "-fx-background-radius:10px;" +
            "-fx-padding:13 0 13 0;" +
            "-fx-cursor:hand;" +
            "-fx-border-width:0;"
        );
        openBtn.setOnMouseEntered(e ->
            openBtn.setStyle(
                "-fx-background-color:#3367D6;" +
                "-fx-text-fill:white;" +
                "-fx-font-size:14px;" +
                "-fx-font-weight:bold;" +
                "-fx-border-radius:10px;" +
                "-fx-background-radius:10px;" +
                "-fx-padding:13 0 13 0;" +
                "-fx-cursor:hand;" +
                "-fx-border-width:0;"
            )
        );
        openBtn.setOnMouseExited(e ->
            openBtn.setStyle(
                "-fx-background-color:#4285F4;" +
                "-fx-text-fill:white;" +
                "-fx-font-size:14px;" +
                "-fx-font-weight:bold;" +
                "-fx-border-radius:10px;" +
                "-fx-background-radius:10px;" +
                "-fx-padding:13 0 13 0;" +
                "-fx-cursor:hand;" +
                "-fx-border-width:0;"
            )
        );
        openBtn.setOnAction(e -> {
            try {
                new ProcessBuilder("cmd", "/c", "start", authUrl).start();
                openBtn.setText("✅  Browser opened — sign in and copy code");
                openBtn.setStyle(
                    "-fx-background-color:#0F8A5F;" +
                    "-fx-text-fill:white;" +
                    "-fx-font-size:13px;" +
                    "-fx-font-weight:bold;" +
                    "-fx-border-radius:10px;" +
                    "-fx-background-radius:10px;" +
                    "-fx-padding:13 0 13 0;" +
                    "-fx-cursor:hand;" +
                    "-fx-border-width:0;"
                );
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // ── Code input ─────────────────────────────────
        Label codeLabel = new Label("Paste authorisation code here:");
        codeLabel.setStyle(
            "-fx-font-size:13px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:#3A3A52;"
        );

        TextField codeField = new TextField();
        codeField.setPromptText("Paste the code from Google here");
        codeField.setStyle(
            "-fx-background-color:#F8F7F4;" +
            "-fx-border-color:#C8C4BC;" +
            "-fx-border-width:1;" +
            "-fx-border-radius:8px;" +
            "-fx-background-radius:8px;" +
            "-fx-text-fill:#1A1A2E;" +
            "-fx-prompt-text-fill:#A8A8B8;" +
            "-fx-padding:12 14 12 14;" +
            "-fx-font-size:13px;"
        );

        // ── Status label ───────────────────────────────
        Label statusLabel = new Label("");
        statusLabel.setStyle(
            "-fx-font-size:12px;" +
            "-fx-text-fill:#C0392B;" +
            "-fx-font-weight:bold;"
        );
        statusLabel.setWrapText(true);

        // ── Continue button ────────────────────────────
        Button continueBtn = new Button("Continue with Google");
        continueBtn.setMaxWidth(Double.MAX_VALUE);
        continueBtn.setStyle(
            "-fx-background-color:#634ED2;" +
            "-fx-text-fill:white;" +
            "-fx-font-size:14px;" +
            "-fx-font-weight:bold;" +
            "-fx-border-radius:10px;" +
            "-fx-background-radius:10px;" +
            "-fx-padding:13 0 13 0;" +
            "-fx-cursor:hand;" +
            "-fx-border-width:0;"
        );

        continueBtn.setOnAction(e -> {
            String code = codeField.getText().trim();
            if (code.isEmpty()) {
                statusLabel.setText(
                    "Please paste the authorisation code from Google first."
                );
                statusLabel.setStyle(
                    "-fx-font-size:12px;" +
                    "-fx-text-fill:#C0392B;" +
                    "-fx-font-weight:bold;"
                );
                return;
            }

            statusLabel.setStyle(
                "-fx-font-size:12px;" +
                "-fx-text-fill:#634ED2;" +
                "-fx-font-weight:bold;"
            );
            statusLabel.setText("⏳  Signing you in...");
            continueBtn.setDisable(true);
            continueBtn.setText("Signing in...");

            GoogleAuthService.getInstance().exchangeCodeForUser(
                code,
                user -> {
                    String googleUserId = "g_" +
                        user.email.split("@")[0]
                            .toLowerCase()
                            .replaceAll("[^a-z0-9]", "");

                    if (!UserDatabase.getInstance()
                            .userIdExists(googleUserId)) {
                        UserDatabase.getInstance().register(
                            user.name,
                            googleUserId,
                            user.email,
                            "GOOGLE_AUTH_" + user.googleId
                        );
                        EmailService.getInstance().sendWelcomeEmail(
                            user.email, user.name, googleUserId
                        );
                    }

                    UserSession.getInstance().setUserName(user.name);
                    UserSession.getInstance().setPatientId(googleUserId);
                    UserSession.getInstance().setEmail(user.email);
  
                    authStage.close();
                    goToMain(user.name);
                },
                error -> {
                    statusLabel.setStyle(
                        "-fx-font-size:12px;" +
                        "-fx-text-fill:#C0392B;" +
                        "-fx-font-weight:bold;"
                    );
                    statusLabel.setText("❌  Error: " + error);
                    continueBtn.setDisable(false);
                    continueBtn.setText("Continue with Google");
                }
            );
        });

        // ── Cancel button ──────────────────────────────
        Button cancelBtn = new Button("Cancel");
        cancelBtn.setMaxWidth(Double.MAX_VALUE);
        cancelBtn.setStyle(
            "-fx-background-color:white;" +
            "-fx-border-color:#C8C4BC;" +
            "-fx-border-width:1;" +
            "-fx-border-radius:10px;" +
            "-fx-background-radius:10px;" +
            "-fx-text-fill:#6B6B80;" +
            "-fx-font-size:13px;" +
            "-fx-padding:10 0 10 0;" +
            "-fx-cursor:hand;"
        );
        cancelBtn.setOnAction(e -> authStage.close());

        // ── Layout ─────────────────────────────────────
        VBox content = new VBox(16,
            stepsBox,
            openBtn,
            codeLabel,
            codeField,
            statusLabel,
            continueBtn,
            cancelBtn
        );
        content.setStyle("-fx-padding:24 28 28 28;");

        VBox root = new VBox(header, content);
        root.setStyle("-fx-background-color:white;");

        Scene scene = new Scene(root, 500, 520);
       URL cssUrl = getClass().getResource(
            "/com/emohealth/css/dark-theme.css"
        );
        if (cssUrl != null) {
            scene.getStylesheets().add(cssUrl.toExternalForm());
        }

        authStage.setScene(scene);
        authStage.show();
    }

    // ── Forgot password ───────────────────────────
    @FXML
    private void onForgotPassword() {
        showForgotPasswordDialog();
    }

    // ── Sign In ───────────────────────────────────
    private void doSignIn() {
        String userId   = userIdField.getText().trim();
        String password = passwordField.getText().trim();

        if (userId.isEmpty())   { showError("Please enter your User ID."); return; }
        if (password.isEmpty()) { showError("Please enter your password."); return; }

        if (!UserDatabase.getInstance().userIdExists(userId)) {
            showError("No account found with this User ID.\nPlease create an account first.");
            return;
        }

        RegisteredUser user = UserDatabase.getInstance().signIn(userId, password);
        if (user == null) {
            showError("Incorrect password. Please try again.");
            return;
        }

        UserSession.getInstance().setUserName(user.getName());
        UserSession.getInstance().setPatientId(user.getUserId());
        UserSession.getInstance().setEmail(user.getEmail());
        goToMain(user.getName());
    }

    // ── Sign Up ───────────────────────────────────
    private void doSignUp() {
        String name     = signUpNameField.getText().trim();
        String userId   = userIdField.getText().trim();
        String email    = emailField.getText().trim();
        String password = passwordField.getText().trim();
        String confirm  = confirmField.getText().trim();

        if (name.isEmpty())     { showError("Please enter your name."); return; }
        if (userId.isEmpty())   { showError("Please choose a User ID."); return; }
        if (userId.contains(" ")){ showError("User ID cannot have spaces."); return; }
        if (userId.length() < 4){ showError("User ID needs at least 4 characters."); return; }
        if (email.isEmpty())    { showError("Please enter your email address."); return; }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            showError("Please enter a valid email address."); return;
        }
        if (password.isEmpty()) { showError("Please enter a password."); return; }
        if (password.length() < 6) {
            showError("Password must be at least 6 characters."); return;
        }
        if (!password.equals(confirm)) {
            showError("Passwords do not match."); return;
        }

        if (UserDatabase.getInstance().userIdExists(userId)) {
            showError("User ID '" + userId + "' is already taken."); return;
        }
        if (UserDatabase.getInstance().emailExists(email)) {
            showError("An account with this email already exists.\nPlease sign in instead.");
            return;
        }

        boolean ok = UserDatabase.getInstance().register(name, userId, email, password);
        if (!ok) { showError("Registration failed. Please try again."); return; }

        // Send welcome email
        EmailService.getInstance().sendWelcomeEmail(email, name, userId);

        UserSession.getInstance().setUserName(name);
        UserSession.getInstance().setPatientId(userId);
        UserSession.getInstance().setEmail(email);
        goToMain(name);
    }

    // ── Forgot password dialog ────────────────────
    private void showForgotPasswordDialog() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Reset password");
        dialog.setResizable(false);

        // Step 1: Enter email
        Label title = new Label("Forgot your password?");
        title.setStyle(
            "-fx-font-size:18px;-fx-font-weight:bold;-fx-text-fill:#1A1A2E;"
        );
        Label sub = new Label(
            "Enter your email address and we will send\n" +
            "you a 6-digit reset code."
        );
        sub.setStyle("-fx-font-size:13px;-fx-text-fill:#6B6B80;");

        TextField emailInput = new TextField();
        emailInput.setPromptText("yourname@email.com");
        emailInput.setStyle(
            "-fx-background-color:#F8F7F4;-fx-border-color:#C8C4BC;" +
            "-fx-border-width:1;-fx-border-radius:8px;" +
            "-fx-background-radius:8px;-fx-text-fill:#1A1A2E;" +
            "-fx-padding:10 14 10 14;-fx-font-size:14px;"
        );

        Label emailError = new Label("");
        emailError.setStyle("-fx-text-fill:#C0392B;-fx-font-size:12px;");

        Button sendBtn = new Button("Send reset code");
        sendBtn.setMaxWidth(Double.MAX_VALUE);
        sendBtn.setStyle(
            "-fx-background-color:#634ED2;-fx-text-fill:white;" +
            "-fx-font-size:14px;-fx-font-weight:bold;" +
            "-fx-border-radius:8px;-fx-background-radius:8px;" +
            "-fx-padding:11 0 11 0;-fx-border-width:0;-fx-cursor:hand;"
        );

        // Step 2: Enter code + new password (hidden initially)
        VBox step2 = new VBox(12);
        step2.setVisible(false); step2.setManaged(false);

        Label codeTitle = new Label("Enter reset code");
        codeTitle.setStyle(
            "-fx-font-size:15px;-fx-font-weight:bold;-fx-text-fill:#1A1A2E;"
        );
        Label codeSub = new Label("");
        codeSub.setStyle("-fx-font-size:13px;-fx-text-fill:#6B6B80;");

        TextField codeInput = new TextField();
        codeInput.setPromptText("Enter 6-digit code");
        codeInput.setStyle(
            "-fx-background-color:#F8F7F4;-fx-border-color:#C8C4BC;" +
            "-fx-border-width:1;-fx-border-radius:8px;" +
            "-fx-background-radius:8px;-fx-text-fill:#1A1A2E;" +
            "-fx-padding:10 14 10 14;-fx-font-size:18px;" +
            "-fx-font-weight:bold;-fx-letter-spacing:4px;"
        );

        PasswordField newPassInput = new PasswordField();
        newPassInput.setPromptText("New password (min 6 characters)");
        newPassInput.setStyle(
            "-fx-background-color:#F8F7F4;-fx-border-color:#C8C4BC;" +
            "-fx-border-width:1;-fx-border-radius:8px;" +
            "-fx-background-radius:8px;-fx-text-fill:#1A1A2E;" +
            "-fx-padding:10 14 10 14;-fx-font-size:14px;"
        );

        PasswordField confirmPassInput = new PasswordField();
        confirmPassInput.setPromptText("Confirm new password");
        confirmPassInput.setStyle(
            "-fx-background-color:#F8F7F4;-fx-border-color:#C8C4BC;" +
            "-fx-border-width:1;-fx-border-radius:8px;" +
            "-fx-background-radius:8px;-fx-text-fill:#1A1A2E;" +
            "-fx-padding:10 14 10 14;-fx-font-size:14px;"
        );

        Label resetError = new Label("");
        resetError.setStyle("-fx-text-fill:#C0392B;-fx-font-size:12px;");

        Button resetBtn = new Button("Reset password");
        resetBtn.setMaxWidth(Double.MAX_VALUE);
        resetBtn.setStyle(
            "-fx-background-color:#634ED2;-fx-text-fill:white;" +
            "-fx-font-size:14px;-fx-font-weight:bold;" +
            "-fx-border-radius:8px;-fx-background-radius:8px;" +
            "-fx-padding:11 0 11 0;-fx-border-width:0;-fx-cursor:hand;"
        );

        step2.getChildren().addAll(
            codeTitle, codeSub, codeInput,
            new Label("New password") {{
                setStyle("-fx-font-size:13px;-fx-font-weight:bold;-fx-text-fill:#3A3A52;");
            }},
            newPassInput,
            new Label("Confirm new password") {{
                setStyle("-fx-font-size:13px;-fx-font-weight:bold;-fx-text-fill:#3A3A52;");
            }},
            confirmPassInput, resetError, resetBtn
        );

        // Send button action
        final String[] savedEmail = {""};
        sendBtn.setOnAction(e -> {
            String em = emailInput.getText().trim();
            if (!EMAIL_PATTERN.matcher(em).matches()) {
                emailError.setText("Please enter a valid email address.");
                return;
            }
            RegisteredUser user = UserDatabase.getInstance().findByEmail(em);
            if (user == null) {
                emailError.setText("No account found with this email.");
                return;
            }

            String code = EmailService.getInstance().generateResetCode();
            UserDatabase.getInstance().saveResetCode(em, code);
            savedEmail[0] = em;

            sendBtn.setText("Sending...");
            sendBtn.setDisable(true);

            EmailService.getInstance().sendResetEmail(
                em, user.getName(), code,
                success -> {
                    if (success) {
                        codeSub.setText(
                            "Code sent to: " + em + "\n" +
                            "Check your inbox. Expires in 15 minutes."
                        );
                        step2.setVisible(true);
                        step2.setManaged(true);
                        sendBtn.setText("Resend code");
                        sendBtn.setDisable(false);
                        emailError.setText("");
                    } else {
                        emailError.setText(
                            "Failed to send email. Check your internet or SMTP settings."
                        );
                        sendBtn.setText("Send reset code");
                        sendBtn.setDisable(false);
                    }
                }
            );
        });

        // Reset button action
        resetBtn.setOnAction(e -> {
            String code    = codeInput.getText().trim();
            String newPass = newPassInput.getText().trim();
            String confPass= confirmPassInput.getText().trim();

            if (code.isEmpty())    { resetError.setText("Enter the reset code."); return; }
            if (newPass.length() < 6) {
                resetError.setText("Password must be at least 6 characters."); return;
            }
            if (!newPass.equals(confPass)) {
                resetError.setText("Passwords do not match."); return;
            }

            boolean valid = UserDatabase.getInstance()
                .verifyResetCode(savedEmail[0], code);
            if (!valid) {
                resetError.setText("Invalid or expired code. Please request a new one.");
                return;
            }

            boolean updated = UserDatabase.getInstance()
                .updatePassword(savedEmail[0], newPass);
            if (updated) {
                dialog.close();
                showInfo("Password reset",
                    "Your password has been reset successfully!\n" +
                    "Please sign in with your new password.");
            } else {
                resetError.setText("Failed to update password. Please try again.");
            }
        });

        VBox root = new VBox(16,
            title, sub, emailInput, emailError, sendBtn, step2
        );
        root.setPadding(new Insets(32));
        root.setStyle("-fx-background-color:white;");
        root.setPrefWidth(420);

        ScrollPane scroll = new ScrollPane(root);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color:white;-fx-border-width:0;");

        Scene scene = new Scene(scroll, 460, 520);
        URL cssUrl = getClass().getResource("/com/emohealth/css/dark-theme.css");
        if (cssUrl != null) scene.getStylesheets().add(cssUrl.toExternalForm());

        dialog.setScene(scene);
        dialog.show();
    }

    // ── Navigate to main screen ───────────────────
    private void goToMain(String name) {
        try {
            URL fxmlUrl = getClass().getResource(
                "/com/emohealth/fxml/MainView.fxml"
            );
            if (fxmlUrl == null) {
                showError("MainView.fxml not found!");
                return;
            }
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Scene scene = new Scene(loader.load(), 1200, 750);
            URL cssUrl = getClass().getResource(
                "/com/emohealth/css/dark-theme.css"
            );
            if (cssUrl != null) scene.getStylesheets().add(cssUrl.toExternalForm());

            Stage stage = (Stage) mainButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("EmotionDetection — " + name);
            stage.setMinWidth(1000);
            stage.setMinHeight(650);
            stage.show();
        } catch (Exception e) {
            showError("Failed to load: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ── Helpers ───────────────────────────────────
    private void showError(String msg)  { errorLabel.setText(msg); }
    private void clearMessages() {
        errorLabel.setText("");
        successLabel.setText("");
    }
    private void clearFields() {
        userIdField.clear();
        passwordField.clear();
        signUpNameField.clear();
        emailField.clear();
        confirmField.clear();
        idAvailableLabel.setText("");
        emailValidLabel.setText("");
    }

    private void setLabel(Label label, String msg, boolean success) {
        label.setText(msg);
        label.setStyle(
            "-fx-font-size:12px;-fx-font-weight:bold;-fx-text-fill:" +
            (success ? "#1A7A4A" : "#C0392B") + ";"
        );
    }

    private void showInfo(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}
