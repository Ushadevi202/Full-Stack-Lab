package com.emohealth.controller;

import com.emohealth.model.EmotionResult;
import com.emohealth.model.HistoryEntry;
import com.emohealth.model.UserSession;
import com.emohealth.service.AudioRecorderService;
import com.emohealth.service.EmotionApiService;
import com.emohealth.service.GroqService;

import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class MainController implements Initializable {

    // ── Pages ─────────────────────────────────────────────────────
    @FXML private VBox       pageMonitor;
    @FXML private VBox       pageHistory;
    @FXML private VBox       pageCalendar;
    @FXML private VBox       pageReports;
    @FXML private ScrollPane pageAiInsight;
    @FXML private VBox       pageGraph;
    @FXML private ScrollPane pageSettings;

    // ── Sidebar nav ───────────────────────────────────────────────
    @FXML private Label sidebarAvatarLabel;
    @FXML private Label sidebarUserName;
    @FXML private Label sidebarUserId;
    @FXML private HBox  navMonitor;
    @FXML private HBox  navHistory;
    @FXML private HBox  navCalendar;
    @FXML private HBox  navReports;
    @FXML private HBox  navAiInsight;
    @FXML private HBox  navGraph;
    @FXML private HBox  navSettings;

    // ── Monitor page ──────────────────────────────────────────────
    @FXML private Label    avatarLabel;
    @FXML private Label    userNameLabel;
    @FXML private Label    userIdLabel;
    @FXML private HBox     liveBadge;
    @FXML private Label    dominantEmotionLabel;
    @FXML private Label    dominantConfLabel;
    @FXML private Label    sessionTimerLabel;
    @FXML private Label    sessionStartLabel;
    @FXML private Label    stressIndexLabel;
    @FXML private Label    stressStatusLabel;
    @FXML private Label    segmentsLabel;
    @FXML private HBox     waveformContainer;
    @FXML private Button   recordButton;
    @FXML private Label    recTimerLabel;
    @FXML private Label    recHintLabel;
    @FXML private Button   uploadButton;
    @FXML private GridPane emotionGrid;

    // ── History page ──────────────────────────────────────────────
    @FXML private VBox   historyTableRows;
    @FXML private Button btnDay;
    @FXML private Button btnMonth;
    @FXML private Button btnYear;

    // ── Calendar page ─────────────────────────────────────────────
    @FXML private Label    calMonthLabel;
    @FXML private GridPane calDayHeaders;
    @FXML private GridPane calGrid;
    @FXML private HBox     calDetailBox;
    @FXML private Label    calDetailDate;
    @FXML private Label    calDetailEmotion;
    @FXML private Label    calDetailStress;
    @FXML private Label    calDetailFeedback;
    @FXML private Label    calDetailSuggestion;

    // ── Reports page ──────────────────────────────────────────────
    @FXML private ComboBox<String> reportPeriod;
    @FXML private TextArea         reportOutput;

    // ── AI Insight page ───────────────────────────────────────────
    @FXML private Label    aiInsightSubLabel;
    @FXML private Label    aiEmotionBadge;
    @FXML private TextArea aiMainInsight;
    @FXML private Button   regenerateBtn;
    @FXML private Label    aiBreathingFull;
    @FXML private Label    aiSuggestionFull;
    @FXML private Label    aiQuoteFull;
    @FXML private Label    aiQuoteAuthorFull;
    @FXML private GridPane aiEmotionMiniGrid;
    @FXML private VBox     aiResourceList;

    // ── Graph page ────────────────────────────────────────────────
    @FXML private javafx.scene.layout.Pane graphPane;
    @FXML private Button graphBtnDay;
    @FXML private Button graphBtnWeek;
    @FXML private Button graphBtnMonth;
    @FXML private HBox   graphDetailBox;
    @FXML private Label  graphDetailDate;
    @FXML private Label  graphDetailEmotion;
    @FXML private Label  graphDetailStress;
    @FXML private Label  graphDetailFeedback;

    // ── Settings page ─────────────────────────────────────────────
    @FXML private TextField          settingsNameField;
    @FXML private Label              settingsUserIdBadge;
    @FXML private Button             toggleReminder;
    @FXML private Button             toggleWeekly;
    @FXML private Button             toggleStressAlert;
    @FXML private Button             toggleSaveRecordings;
    @FXML private ComboBox<String>   micSensitivity;
    @FXML private ComboBox<String>   analysisInterval;
    @FXML private ComboBox<String>   fontSizeCombo;
    @FXML private ComboBox<String>   languageCombo;

    // ── State ─────────────────────────────────────────────────────
    private boolean   isRecording    = false;
    private int       sessionSeconds = 0;
    private int       recSeconds     = 0;
    private int       segmentCount   = 0;
    private String    currentFilter  = "Day";
    private String    graphFilter    = "Day";
    private String    currentPage    = "monitor";
    private YearMonth calendarMonth;
    

    private Timeline       sessionTimer;
    private Timeline       recTimer;
    private AnimationTimer waveTimer;
    private EmotionResult  lastResult;

    private final List<Rectangle>    waveBars   = new ArrayList<>();
    private final List<HistoryEntry> allHistory = new ArrayList<>();
    private final Random rng = new Random();

    private AudioRecorderService audioService;
    private EmotionApiService    emotionService;
    private GroqService          groqService;

    // ── Emotion config ────────────────────────────────────────────
    private static final Map<String, String[]> EMOTION_CONFIG =
        new LinkedHashMap<>();
    static {
        EMOTION_CONFIG.put("Happy",   new String[]{"#0F8A5F", "chip-teal"});
        EMOTION_CONFIG.put("Sad",     new String[]{"#5040A0", "chip-purple"});
        EMOTION_CONFIG.put("Surprise",new String[]{"#A0306A", "chip-pink"});
        EMOTION_CONFIG.put("Angry",   new String[]{"#C0392B", "chip-red"});
        EMOTION_CONFIG.put("Fear",    new String[]{"#B87A00", "chip-amber"});
        EMOTION_CONFIG.put("Neutral", new String[]{"#505065", "chip-gray"});
        EMOTION_CONFIG.put("Disgust", new String[]{"#6B4226", "chip-disgust"});
    }

    // ── Initialize ────────────────────────────────────────────────
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        audioService   = new AudioRecorderService();
        emotionService = new EmotionApiService();
        groqService    = GroqService.getInstance();
        calendarMonth  = YearMonth.now();

        loadUserInfo();
        buildWaveform();
        buildEmotionChips(buildDefaultScores());
        buildCalendar();
        setupReportPeriod();
        loadDefaultInsight();

        
        

        // Check Groq status
        new Thread(() ->
            Platform.runLater(this::checkAiStatus)
        ).start();

        // Redraw graph when pane resizes
        if (graphPane != null) {
            graphPane.widthProperty().addListener(
                (obs, o, n) -> { if ("graph".equals(currentPage)) buildGraph(); }
            );
            graphPane.heightProperty().addListener(
                (obs, o, n) -> { if ("graph".equals(currentPage)) buildGraph(); }
            );
        }

        try {
            setupSettings();
        } catch (Exception e) {
            System.out.println("Settings skipped: " + e.getMessage());
        }
    }

    // ── Load user info ────────────────────────────────────────────
    private void loadUserInfo() {
        UserSession s   = UserSession.getInstance();
        String name     = s.getUserName()  != null ? s.getUserName()  : "Guest";
        String id       = s.getPatientId() != null ? s.getPatientId() : "user0000";
        String initials = s.getInitials();

        sidebarAvatarLabel.setText(initials);
        sidebarUserName.setText(toTitleCase(name));
        sidebarUserId.setText(id);
        avatarLabel.setText(initials);
        userNameLabel.setText(toTitleCase(name));
        userIdLabel.setText(id + "  ·  Session " +
            (getUserHistory().size() + 1));
    }

    // ── Get current user history only ─────────────────────────────
    private List<HistoryEntry> getUserHistory() {
        String uid = UserSession.getInstance().getPatientId();
        if (uid == null) return new ArrayList<>();
        return allHistory.stream()
            .filter(e -> uid.equals(e.getOwnerUserId()))
            .collect(Collectors.toList());
    }

    // ── Waveform ──────────────────────────────────────────────────
    private void buildWaveform() {
        waveformContainer.getChildren().clear();
        waveBars.clear();
        for (int i = 0; i < 52; i++) {
            Rectangle bar = new Rectangle(4, 8);
            bar.setArcWidth(2); bar.setArcHeight(2);
            bar.setFill(Color.web("#C4B8F0"));
            bar.setOpacity(0.5);
            waveBars.add(bar);
            waveformContainer.getChildren().add(bar);
        }
    }

    private void startWaveAnimation() {
        waveTimer = new AnimationTimer() {
            long last = 0;
            @Override public void handle(long now) {
                if (now - last < 80_000_000L) return;
                last = now;
                for (Rectangle bar : waveBars) {
                    double h = 8 + rng.nextDouble() * 58;
                    bar.setHeight(h);
                    bar.setOpacity(0.4 + rng.nextDouble() * 0.6);
                    bar.setFill(Color.web(
                        h > 48 ? "#634ED2" :
                        h > 28 ? "#8B78E8" : "#B0A4F0"
                    ));
                }
            }
        };
        waveTimer.start();
    }

    private void stopWaveAnimation() {
        if (waveTimer != null) waveTimer.stop();
        for (Rectangle bar : waveBars) {
            bar.setHeight(8);
            bar.setOpacity(0.4);
            bar.setFill(Color.web("#C4B8F0"));
        }
    }

    // ── Record ────────────────────────────────────────────────────
    @FXML
    private void onToggleRecording() {
        isRecording = !isRecording;
        if (isRecording) startRecording(); else pauseRecording();
    }

    private void startRecording() {
        recordButton.setText("⏸");
        recHintLabel.setText("Tap to pause");
        liveBadge.setVisible(true);
        uploadButton.setDisable(true);

        String now = java.time.LocalTime.now()
            .format(DateTimeFormatter.ofPattern("h:mm a"));
        sessionStartLabel.setText("Started " + now);

        sessionTimer = new Timeline(
            new KeyFrame(Duration.seconds(1), e -> {
                sessionSeconds++;
                sessionTimerLabel.setText(formatTime(sessionSeconds));
                if (sessionSeconds % 20 == 0) analyseSegment();
            })
        );
        sessionTimer.setCycleCount(Timeline.INDEFINITE);
        sessionTimer.play();

        recSeconds = 0;
        recTimer = new Timeline(
            new KeyFrame(Duration.seconds(1), e -> {
                recSeconds++;
                recTimerLabel.setText(formatTime(recSeconds));
            })
        );
        recTimer.setCycleCount(Timeline.INDEFINITE);
        recTimer.play();

        startWaveAnimation();
        audioService.startRecording();
        new Timeline(new KeyFrame(Duration.seconds(3),
            e -> analyseSegment())).play();
    }

    private void pauseRecording() {
        recordButton.setText("▶");
        recHintLabel.setText("Tap to start");
        liveBadge.setVisible(false);
        uploadButton.setDisable(false);
        if (sessionTimer != null) sessionTimer.stop();
        if (recTimer     != null) recTimer.stop();
        stopWaveAnimation();
        audioService.stopRecording();
    }

    // ── Upload ────────────────────────────────────────────────────
    @FXML
    private void onUploadVoice() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Select a voice clip");
        fc.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter(
                "Audio files", "*.wav","*.mp3","*.ogg","*.m4a"),
            new FileChooser.ExtensionFilter("All files","*.*")
        );
        Stage stage = (Stage) uploadButton.getScene().getWindow();
        File file = fc.showOpenDialog(stage);
        if (file != null) {
            recHintLabel.setText("Analysing: " + file.getName());
            uploadButton.setDisable(true);
            recordButton.setDisable(true);
            startWaveAnimation();
            new Timeline(new KeyFrame(Duration.seconds(2), e -> {
                stopWaveAnimation();
                analyseSegment();
                uploadButton.setDisable(false);
                recordButton.setDisable(false);
                recHintLabel.setText("Done: " + file.getName());
            })).play();
        }
    }

    // ── Analyse segment ───────────────────────────────────────────
    private void analyseSegment() {
        segmentCount++;
        segmentsLabel.setText(String.valueOf(segmentCount));
        emotionService.analyseAsync(
            audioService.getLatestChunk(),
            result -> Platform.runLater(() -> updateEmotionUI(result))
        );
    }

    // ── Update UI with result ─────────────────────────────────────
    private void updateEmotionUI(EmotionResult result) {
        String emotion = result.getDominantEmotion();
        int    conf    = result.getTopConfidence();
        double stress  = result.getStressIndex();

        // Metric cards
        dominantEmotionLabel.setText(emotion);
        dominantConfLabel.setText("Confidence · " + conf + "%");
        stressIndexLabel.setText(String.format("%.1f / 10", stress));
        stressStatusLabel.setText(
            stress > 6 ? "Above average" :
            stress > 4 ? "Moderate"      : "Low — you are doing well"
        );

        // Emotion chips
        buildEmotionChips(result.getScores());

        // Build feedback
        String feedback   = HistoryEntry.buildFeedback(emotion, stress);
        String suggestion = HistoryEntry.buildSuggestion(emotion);

        // Save to history with current user ID
        String currentUserId = UserSession.getInstance().getPatientId();
        HistoryEntry entry = new HistoryEntry(
            currentUserId, emotion, conf, stress, feedback, suggestion
        );
        allHistory.add(0, entry);

        // Refresh pages
        refreshHistoryTable();
        buildCalendar();

        // Update AI insight page
        updateAiInsightPage(result);
    }

    // ── Emotion chips ─────────────────────────────────────────────
    private void buildEmotionChips(Map<String, Integer> scores) {
        emotionGrid.getChildren().clear();
        int col = 0, row = 0;
        for (Map.Entry<String, Integer> e : scores.entrySet()) {
            emotionGrid.add(
                createEmotionChip(e.getKey(), e.getValue()), col, row
            );
            if (++col == 3) { col = 0; row++; }
        }
    }

    private VBox createEmotionChip(String emotion, int pct) {
        String[] cfg = EMOTION_CONFIG.getOrDefault(
            emotion, new String[]{"#505065","chip-gray"}
        );
        String color = cfg[0];

        VBox chip = new VBox(6);
        chip.getStyleClass().addAll("emotion-chip", cfg[1]);
        chip.setPadding(new Insets(12));
        chip.setOnMouseClicked(e -> showEmotionDetail(emotion, pct));
        chip.setStyle("-fx-cursor:hand;");

        Label name = new Label(emotion);
        name.setStyle(
            "-fx-font-size:13px;-fx-font-weight:bold;" +
            "-fx-text-fill:" + color + ";"
        );

        StackPane track = new StackPane();
        track.setPrefHeight(5); track.setMaxHeight(5);
        track.setStyle(
            "-fx-background-color:#E8E4E0;-fx-background-radius:3;"
        );
        Region fill = new Region();
        fill.setPrefHeight(5);
        fill.setStyle(
            "-fx-background-color:" + color + ";-fx-background-radius:3;"
        );
        HBox bar = new HBox(fill);
        fill.prefWidthProperty().bind(
            bar.widthProperty().multiply(pct / 100.0)
        );
        track.getChildren().add(bar);
        StackPane.setAlignment(bar, Pos.CENTER_LEFT);

        Label pctLabel = new Label(pct + "%");
        pctLabel.setStyle(
            "-fx-font-size:12px;-fx-font-weight:bold;" +
            "-fx-text-fill:" + color + ";"
        );

        chip.getChildren().addAll(name, track, pctLabel);
        return chip;
    }

    private void showEmotionDetail(String emotion, int pct) {
        String[] cfg   = EMOTION_CONFIG.getOrDefault(
            emotion, new String[]{"#505065","chip-gray"}
        );
        String[] quote = HistoryEntry.buildQuote(emotion);
        showBeautifulDialog(
            emotion,
            pct + "% detected",
            cfg[0],
            HistoryEntry.buildFeedback(emotion, 5.0),
            HistoryEntry.buildSuggestion(emotion),
            HistoryEntry.buildBreathingSteps(emotion),
            quote,
            HistoryEntry.buildResources(emotion)
        );
    }

    // ── History ───────────────────────────────────────────────────
    @FXML private void onFilterDay() {
        currentFilter = "Day";
        updateFilterButtons();
        refreshHistoryTable();
    }
    @FXML private void onFilterMonth() {
        currentFilter = "Month";
        updateFilterButtons();
        refreshHistoryTable();
    }
    @FXML private void onFilterYear() {
        currentFilter = "Year";
        updateFilterButtons();
        refreshHistoryTable();
    }

    private void updateFilterButtons() {
        btnDay.getStyleClass().removeAll("filter-btn-active","filter-btn");
        btnMonth.getStyleClass().removeAll("filter-btn-active","filter-btn");
        btnYear.getStyleClass().removeAll("filter-btn-active","filter-btn");
        switch (currentFilter) {
            case "Day"   -> btnDay.getStyleClass().add("filter-btn-active");
            case "Month" -> btnMonth.getStyleClass().add("filter-btn-active");
            case "Year"  -> btnYear.getStyleClass().add("filter-btn-active");
        }
        if (!btnDay.getStyleClass().contains("filter-btn-active"))
            btnDay.getStyleClass().add("filter-btn");
        if (!btnMonth.getStyleClass().contains("filter-btn-active"))
            btnMonth.getStyleClass().add("filter-btn");
        if (!btnYear.getStyleClass().contains("filter-btn-active"))
            btnYear.getStyleClass().add("filter-btn");
    }

    private void refreshHistoryTable() {
        historyTableRows.getChildren().clear();
        LocalDate today = LocalDate.now();
        String currentUserId = UserSession.getInstance().getPatientId();

        List<HistoryEntry> filtered = allHistory.stream()
            .filter(e -> currentUserId != null &&
                         currentUserId.equals(e.getOwnerUserId()))
            .filter(e -> switch (currentFilter) {
                case "Day"   -> e.getDay()   == today.getDayOfMonth()
                             && e.getMonth() == today.getMonthValue()
                             && e.getYear()  == today.getYear();
                case "Month" -> e.getMonth() == today.getMonthValue()
                             && e.getYear()  == today.getYear();
                case "Year"  -> e.getYear()  == today.getYear();
                default -> true;
            }).collect(Collectors.toList());

        if (filtered.isEmpty()) {
            Label empty = new Label(
                "No records found for this period.\n" +
                "Complete a voice check-in to see your history here."
            );
            empty.setStyle(
                "-fx-text-fill:#8080A0;-fx-padding:24;" +
                "-fx-font-size:13px;"
            );
            historyTableRows.getChildren().add(empty);
            return;
        }

        for (HistoryEntry entry : filtered) {
            historyTableRows.getChildren().add(buildHistoryRow(entry));
        }
    }

    private HBox buildHistoryRow(HistoryEntry entry) {
        String[] cfg = EMOTION_CONFIG.getOrDefault(
            entry.getEmotion(), new String[]{"#505065","chip-gray"}
        );
        HBox row = new HBox(0);
        row.getStyleClass().add("history-row");
        row.setAlignment(Pos.CENTER_LEFT);
        row.setOnMouseClicked(e -> showHistoryDetail(entry));
        row.setStyle("-fx-cursor:hand;");

        Label time = makeCell(entry.getFormattedDateTime(), 160);
        time.setStyle("-fx-text-fill:#7070908;-fx-font-size:12px;");

        Label emotion = makeCell(entry.getEmotion(), 120);
        emotion.setStyle(
            "-fx-text-fill:" + cfg[0] +
            ";-fx-font-weight:bold;-fx-font-size:13px;"
        );

        Label conf = makeCell(entry.getConfidence() + "%", 100);
        conf.setStyle("-fx-text-fill:#505070;-fx-font-size:12px;");

        Label stress = makeCell(
            String.format("%.1f / 10", entry.getStressIndex()), 100
        );
        stress.setStyle(
            "-fx-text-fill:" +
            (entry.getStressIndex() > 6 ? "#C0392B" :
             entry.getStressIndex() > 4 ? "#B87A00" : "#0F8A5F") +
            ";-fx-font-size:12px;-fx-font-weight:bold;"
        );

        Label feedback = new Label(entry.getAiFeedback());
        feedback.setStyle("-fx-text-fill:#606080;-fx-font-size:12px;");
        HBox.setHgrow(feedback, Priority.ALWAYS);

        row.getChildren().addAll(time, emotion, conf, stress, feedback);
        return row;
    }

    private Label makeCell(String text, double width) {
        Label l = new Label(text);
        l.setMinWidth(width); l.setPrefWidth(width);
        l.setPadding(new Insets(10, 8, 10, 8));
        return l;
    }

    private void showHistoryDetail(HistoryEntry entry) {
        String[] cfg   = EMOTION_CONFIG.getOrDefault(
            entry.getEmotion(), new String[]{"#505065","chip-gray"}
        );
        String[] quote = HistoryEntry.buildQuote(entry.getEmotion());
        showBeautifulDialog(
            entry.getEmotion(),
            entry.getFormattedDateTime() + "  ·  " +
            entry.getConfidence() + "%  ·  Stress: " +
            String.format("%.1f", entry.getStressIndex()) + "/10",
            cfg[0],
            entry.getAiFeedback(),
            entry.getSuggestions(),
            entry.getBreathingSteps(),
            quote,
            HistoryEntry.buildResources(entry.getEmotion())
        );
    }

    // ── Calendar ──────────────────────────────────────────────────
    private void buildCalendar() {
        String month = calendarMonth.getMonth().toString();
        calMonthLabel.setText(
            month.charAt(0) + month.substring(1).toLowerCase() +
            " " + calendarMonth.getYear()
        );

        calDayHeaders.getChildren().clear();
        String[] days = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
        for (int i = 0; i < 7; i++) {
            Label h = new Label(days[i]);
            h.setMaxWidth(Double.MAX_VALUE);
            h.setAlignment(Pos.CENTER);
            h.setStyle(
                "-fx-text-fill:#9090A8;-fx-font-size:12px;" +
                "-fx-font-weight:bold;-fx-padding:4;"
            );
            calDayHeaders.add(h, i, 0);
        }

        calGrid.getChildren().clear();
        int firstDay    = calendarMonth.atDay(1)
            .getDayOfWeek().getValue() % 7;
        int daysInMonth = calendarMonth.lengthOfMonth();
        int col = firstDay, row = 0;

        for (int d = 1; d <= daysInMonth; d++) {
            calGrid.add(buildCalCell(d), col, row);
            if (++col == 7) { col = 0; row++; }
        }
    }

    private VBox buildCalCell(int day) {
        String currentUserId = UserSession.getInstance().getPatientId();

        List<HistoryEntry> dayEntries = allHistory.stream()
            .filter(e -> currentUserId != null &&
                         currentUserId.equals(e.getOwnerUserId()))
            .filter(e -> e.getDay()   == day
                      && e.getMonth() == calendarMonth.getMonthValue()
                      && e.getYear()  == calendarMonth.getYear())
            .collect(Collectors.toList());

        boolean isToday = day == LocalDate.now().getDayOfMonth()
            && calendarMonth.getMonthValue() ==
               LocalDate.now().getMonthValue()
            && calendarMonth.getYear() == LocalDate.now().getYear();

        VBox cell = new VBox(4);
        cell.setAlignment(Pos.TOP_CENTER);
        cell.setPadding(new Insets(6));
        cell.setMinHeight(64);
        cell.setStyle(
            "-fx-background-color:" +
            (isToday ? "#EEE8FF" : "#FFFFFF") +
            ";-fx-background-radius:8px;" +
            "-fx-border-color:" +
            (isToday ? "#8060D0" : "#DDD9D0") +
            ";-fx-border-radius:8px;-fx-border-width:1.5;"
        );

        Label dayLabel = new Label(String.valueOf(day));
        dayLabel.setStyle(
            "-fx-font-size:13px;-fx-font-weight:bold;" +
            "-fx-text-fill:" +
            (isToday ? "#5340B8" : "#3A3A52") + ";"
        );
        cell.getChildren().add(dayLabel);

        if (!dayEntries.isEmpty()) {
            HistoryEntry latest = dayEntries.get(0);
            String[] cfg = EMOTION_CONFIG.getOrDefault(
                latest.getEmotion(),
                new String[]{"#505065","chip-gray"}
            );
            Circle dot = new Circle(5);
            dot.setFill(Color.web(cfg[0]));
            Label emo = new Label(latest.getEmotion());
            emo.setStyle(
                "-fx-font-size:10px;-fx-font-weight:bold;" +
                "-fx-text-fill:" + cfg[0] + ";"
            );
            cell.getChildren().addAll(dot, emo);
            cell.setOnMouseClicked(e ->
                showCalDayDetail(day, dayEntries)
            );
            cell.setStyle(cell.getStyle() + "-fx-cursor:hand;");
        }
        return cell;
    }

    private void showCalDayDetail(int day,
                                   List<HistoryEntry> entries) {
        if (entries.isEmpty()) return;
        HistoryEntry latest = entries.get(0);
        String[] cfg = EMOTION_CONFIG.getOrDefault(
            latest.getEmotion(),
            new String[]{"#505065","chip-gray"}
        );
        String month = calendarMonth.getMonth().toString();

        calDetailBox.setVisible(true);
        calDetailDate.setText(
            day + " " + month.charAt(0) +
            month.substring(1).toLowerCase() +
            " " + calendarMonth.getYear() +
            "  ·  " + entries.size() + " session(s)"
        );
        calDetailEmotion.setText(
            latest.getEmotion() + "   " +
            latest.getConfidence() + "%"
        );
        calDetailEmotion.setStyle(
            "-fx-font-size:18px;-fx-font-weight:bold;" +
            "-fx-text-fill:" + cfg[0] + ";"
        );
        calDetailStress.setText(
            "Stress level: " +
            String.format("%.1f", latest.getStressIndex()) + " / 10"
        );
        calDetailFeedback.setText(latest.getAiFeedback());
        if (calDetailSuggestion != null)
            calDetailSuggestion.setText(
                "Tip: " + latest.getSuggestions()
            );
    }

    @FXML private void onCalPrev() {
        calendarMonth = calendarMonth.minusMonths(1);
        buildCalendar();
        calDetailBox.setVisible(false);
    }

    @FXML private void onCalNext() {
        calendarMonth = calendarMonth.plusMonths(1);
        buildCalendar();
        calDetailBox.setVisible(false);
    }

    // ── Reports ───────────────────────────────────────────────────
    private void setupReportPeriod() {
        if (reportPeriod != null) {
            reportPeriod.getItems().addAll(
                "Today","This week","This month",
                "This year","All time"
            );
            reportPeriod.setValue("This month");
        }
    }

    @FXML
    private void onGenerateReport() {
        String currentUserId = UserSession.getInstance().getPatientId();
        List<HistoryEntry> userHistory = allHistory.stream()
            .filter(e -> currentUserId != null &&
                         currentUserId.equals(e.getOwnerUserId()))
            .collect(Collectors.toList());

        if (userHistory.isEmpty()) {
            if (reportOutput != null)
                reportOutput.setText(
                    "No sessions yet.\n" +
                    "Complete a voice check-in first."
                );
            return;
        }

        String period = reportPeriod != null ?
            reportPeriod.getValue() : "All time";
        String name   = toTitleCase(
            UserSession.getInstance().getUserName()
        );

        Map<String, Long> freq = userHistory.stream().collect(
            Collectors.groupingBy(
                HistoryEntry::getEmotion, Collectors.counting()
            )
        );
        String dominant = freq.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey).orElse("Neutral");

        double avgStress = userHistory.stream()
            .mapToDouble(HistoryEntry::getStressIndex)
            .average().orElse(0);

        String[] quote = HistoryEntry.buildQuote(dominant);
        List<String> res = HistoryEntry.buildResources(dominant);

        String report =
            "═══════════════════════════════════════\n" +
            "   EmotionDetection  AI Wellness Report\n" +
            "═══════════════════════════════════════\n\n" +
            "Name       : " + name + "\n" +
            "Period     : " + period + "\n" +
            "Generated  : " + LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("dd MMM yyyy  h:mm a")
            ) + "\n\n" +
            "── Summary ──────────────────────────\n" +
            "Total sessions   : " + userHistory.size() + "\n" +
            "Dominant emotion : " + dominant + "\n" +
            "Avg stress index : " +
            String.format("%.1f", avgStress) + " / 10\n\n" +
            "── AI Wellness Analysis ─────────────\n" +
            HistoryEntry.buildFeedback(dominant, avgStress) + "\n\n" +
            "── What You Can Do ──────────────────\n" +
            HistoryEntry.buildSuggestion(dominant) + "\n\n" +
            "── Breathing Exercise ───────────────\n" +
            HistoryEntry.buildBreathingSteps(dominant) + "\n\n" +
            "── Motivational Quote ───────────────\n" +
            quote[0] + "\n" + quote[1] + "\n\n" +
            "── Emotion Breakdown ────────────────\n" +
            freq.entrySet().stream()
                .sorted(Map.Entry.<String,Long>
                    comparingByValue().reversed())
                .map(e -> String.format(
                    "%-12s : %d session(s)",
                    e.getKey(), e.getValue()))
                .collect(Collectors.joining("\n")) + "\n\n" +
            "── Mental Health Resources ──────────\n" +
            res.stream().map(r -> "• " + r)
                .collect(Collectors.joining("\n")) + "\n\n" +
            "═══════════════════════════════════════\n" +
            "  EmotionDetection · Your wellness companion\n" +
            "═══════════════════════════════════════";

        if (reportOutput != null) reportOutput.setText(report);
    }

    // ── AI Insight page ───────────────────────────────────────────
    @FXML private void onNavAiInsight() {
        showPage("aiinsight");
        if (lastResult != null) updateAiInsightPage(lastResult);
    }

    @FXML private void onCheckOllama() { checkAiStatus(); }

    private void checkAiStatus() {
        boolean ok = GroqService.getInstance().isAvailable();
        if (aiInsightSubLabel != null && !ok) {
            aiInsightSubLabel.setText(
                "Add your Groq API key to GroqService.java " +
                "to enable AI analysis."
            );
        }
    }

    @FXML
    private void onRegenerateInsight() {
        if (lastResult == null) {
            if (aiMainInsight != null)
                aiMainInsight.setText(
                    "Please complete a voice check-in first."
                );
            return;
        }
        generateGroqInsight(lastResult);
    }

    private void generateGroqInsight(EmotionResult result) {
        if (aiMainInsight == null) return;
        String name = toTitleCase(
            UserSession.getInstance().getUserName()
        );
        aiMainInsight.setText("✦ AI is thinking...");
        if (regenerateBtn != null) regenerateBtn.setDisable(true);

        GroqService.getInstance().generateWellnessInsight(
            result.getDominantEmotion(),
            result.getStressIndex(),
            name,
            response -> {
                aiMainInsight.setText(response);
                if (regenerateBtn != null)
                    regenerateBtn.setDisable(false);
            },
            error -> {
                aiMainInsight.setText(
                    "AI could not generate insight.\n\n" +
                    "Make sure your Groq API key is set in " +
                    "GroqService.java\n\n" +
                    "Get a free key at: console.groq.com"
                );
                if (regenerateBtn != null)
                    regenerateBtn.setDisable(false);
            }
        );
    }

    private void updateAiInsightPage(EmotionResult result) {
        lastResult = result;
        String emotion = result.getDominantEmotion();
        String[] cfg   = EMOTION_CONFIG.getOrDefault(
            emotion, new String[]{"#505065","chip-gray"}
        );
        String[] quote = HistoryEntry.buildQuote(emotion);

        if (aiEmotionBadge != null) {
            aiEmotionBadge.setText(
                emotion + "  " + result.getTopConfidence() + "%"
            );
            aiEmotionBadge.setStyle(
                "-fx-background-color:" + cfg[0] + "22;" +
                "-fx-text-fill:" + cfg[0] + ";" +
                "-fx-font-size:14px;-fx-font-weight:bold;" +
                "-fx-padding:6 16 6 16;" +
                "-fx-background-radius:20px;" +
                "-fx-border-color:" + cfg[0] + "55;" +
                "-fx-border-width:1;-fx-border-radius:20px;"
            );
        }

        if (aiInsightSubLabel != null) {
            aiInsightSubLabel.setText(
                "Based on your latest voice analysis  ·  " +
                "Stress: " +
                String.format("%.1f", result.getStressIndex()) +
                " / 10  ·  " +
                result.getTopConfidence() + "% confidence"
            );
        }

        if (aiBreathingFull != null)
            aiBreathingFull.setText(
                HistoryEntry.buildBreathingSteps(emotion)
            );
        if (aiSuggestionFull != null)
            aiSuggestionFull.setText(
                HistoryEntry.buildSuggestion(emotion)
            );
        if (aiQuoteFull != null)      aiQuoteFull.setText(quote[0]);
        if (aiQuoteAuthorFull != null) aiQuoteAuthorFull.setText(quote[1]);

        // Resources
        if (aiResourceList != null) {
            aiResourceList.getChildren().clear();
            Map<String, String> linkMap = new LinkedHashMap<>();
            linkMap.put("icallhelpline",
                "https://icallhelpline.org");
            linkMap.put("nimhansdigital",
                "https://nimhansdigitalacademy.in");
            linkMap.put("nimhans",  "https://nimhans.ac.in");
            linkMap.put("headspace","https://www.headspace.com");
            linkMap.put("calm",     "https://www.calm.com");
            linkMap.put("7 cups",   "https://www.7cups.com");
            linkMap.put("mindshift",
                "https://www.anxietycanada.com/resources/mindshift-cbt");
            linkMap.put("livelovlaugh",
                "https://www.thelivelovelaughfoundation.org");

            for (String r : HistoryEntry.buildResources(emotion)) {
                HBox rowBox = new HBox(10);
                rowBox.setAlignment(Pos.CENTER_LEFT);
                rowBox.setStyle(
                    "-fx-background-color:#F8F9FF;" +
                    "-fx-border-color:#D0D8F0;" +
                    "-fx-border-width:1;" +
                    "-fx-border-radius:8px;" +
                    "-fx-background-radius:8px;" +
                    "-fx-padding:10 14 10 14;"
                );

                String rLow = r.toLowerCase();
                String url  = linkMap.entrySet().stream()
                    .filter(e -> rLow.contains(e.getKey()))
                    .map(Map.Entry::getValue)
                    .findFirst().orElse(null);

                Label icon = new Label(url != null ? "🔗" : "📞");
                icon.setStyle("-fx-font-size:14px;");

                Label item = new Label(r);
                item.setWrapText(true);
                HBox.setHgrow(item, Priority.ALWAYS);

                if (url != null) {
                    final String finalUrl = url;
                    item.setStyle(
                        "-fx-font-size:13px;" +
                        "-fx-text-fill:#2355C8;" +
                        "-fx-underline:true;-fx-cursor:hand;"
                    );
                    Label openLbl = new Label("Open ↗");
                    openLbl.setStyle(
                        "-fx-font-size:12px;" +
                        "-fx-text-fill:#634ED2;" +
                        "-fx-font-weight:bold;-fx-cursor:hand;"
                    );
                    rowBox.setOnMouseClicked(e -> {
                        try {
                            new ProcessBuilder(
                                "cmd","/c","start",finalUrl
                            ).start();
                        } catch (Exception ex) {
                            System.err.println(ex.getMessage());
                        }
                    });
                    rowBox.setStyle(
                        rowBox.getStyle() + "-fx-cursor:hand;"
                    );
                    rowBox.getChildren().addAll(icon, item, openLbl);
                } else {
                    item.setStyle(
                        "-fx-font-size:13px;-fx-text-fill:#2A2A42;"
                    );
                    rowBox.getChildren().addAll(icon, item);
                }
                aiResourceList.getChildren().add(rowBox);
            }
        }

        if (aiEmotionMiniGrid != null)
            buildMiniEmotionGrid(result.getScores());

        generateGroqInsight(result);
    }

    private void buildMiniEmotionGrid(Map<String, Integer> scores) {
        aiEmotionMiniGrid.getChildren().clear();
        int col = 0, row = 0;
        for (Map.Entry<String, Integer> e : scores.entrySet()) {
            String[] cfg = EMOTION_CONFIG.getOrDefault(
                e.getKey(), new String[]{"#505065","chip-gray"}
            );
            VBox chip = new VBox(4);
            chip.setStyle(
                "-fx-background-color:" + cfg[0] + "18;" +
                "-fx-border-color:" + cfg[0] + "55;" +
                "-fx-border-width:1;-fx-border-radius:8px;" +
                "-fx-background-radius:8px;-fx-padding:10;"
            );
            Label name = new Label(e.getKey());
            name.setStyle(
                "-fx-font-size:12px;-fx-font-weight:bold;" +
                "-fx-text-fill:" + cfg[0] + ";"
            );
            Label pct = new Label(e.getValue() + "%");
            pct.setStyle(
                "-fx-font-size:14px;-fx-font-weight:bold;" +
                "-fx-text-fill:" + cfg[0] + ";"
            );
            chip.getChildren().addAll(name, pct);
            aiEmotionMiniGrid.add(chip, col, row);
            if (++col == 4) { col = 0; row++; }
        }
    }

    private void loadDefaultInsight() {
        String[] quote = HistoryEntry.buildQuote("Neutral");
        if (aiQuoteFull != null)      aiQuoteFull.setText(quote[0]);
        if (aiQuoteAuthorFull != null) aiQuoteAuthorFull.setText(quote[1]);
        if (aiMainInsight != null) {
            aiMainInsight.setText(
                "Complete a voice check-in on the Live Check-in page\n" +
                "to receive your personalised AI wellness analysis.\n\n" +
                "The AI will provide:\n\n" +
                "• Personalised emotional support message\n" +
                "• Specific breathing exercises for your mood\n" +
                "• Actionable tips to improve how you feel\n" +
                "• Motivational quote matched to your emotion"
            );
        }
    }

    // ── Graph page ────────────────────────────────────────────────
    @FXML private void onNavGraph() {
        showPage("graph");
        buildGraph();
    }

    @FXML private void onGraphFilterDay() {
        graphFilter = "Day";
        updateGraphFilterButtons();
        buildGraph();
    }

    @FXML private void onGraphFilterWeek() {
        graphFilter = "Week";
        updateGraphFilterButtons();
        buildGraph();
    }

    @FXML private void onGraphFilterMonth() {
        graphFilter = "Month";
        updateGraphFilterButtons();
        buildGraph();
    }

    private void updateGraphFilterButtons() {
        graphBtnDay.getStyleClass()
            .removeAll("filter-btn-active","filter-btn");
        graphBtnWeek.getStyleClass()
            .removeAll("filter-btn-active","filter-btn");
        graphBtnMonth.getStyleClass()
            .removeAll("filter-btn-active","filter-btn");
        switch (graphFilter) {
            case "Day"   -> graphBtnDay.getStyleClass()
                .add("filter-btn-active");
            case "Week"  -> graphBtnWeek.getStyleClass()
                .add("filter-btn-active");
            case "Month" -> graphBtnMonth.getStyleClass()
                .add("filter-btn-active");
        }
        if (!graphBtnDay.getStyleClass().contains("filter-btn-active"))
            graphBtnDay.getStyleClass().add("filter-btn");
        if (!graphBtnWeek.getStyleClass().contains("filter-btn-active"))
            graphBtnWeek.getStyleClass().add("filter-btn");
        if (!graphBtnMonth.getStyleClass().contains("filter-btn-active"))
            graphBtnMonth.getStyleClass().add("filter-btn");
    }

    private void buildGraph() {
        if (graphPane == null) return;
        graphPane.getChildren().clear();
        if (graphDetailBox != null) graphDetailBox.setVisible(false);

        String currentUserId = UserSession.getInstance().getPatientId();
        LocalDate today = LocalDate.now();

        List<HistoryEntry> filtered = allHistory.stream()
            .filter(e -> currentUserId != null &&
                         currentUserId.equals(e.getOwnerUserId()))
            .filter(e -> switch (graphFilter) {
                case "Day"   -> e.getDay()   == today.getDayOfMonth()
                             && e.getMonth() == today.getMonthValue()
                             && e.getYear()  == today.getYear();
                case "Week"  -> e.getDateTime().isAfter(
                    LocalDateTime.now().minusDays(7));
                case "Month" -> e.getMonth() == today.getMonthValue()
                             && e.getYear()  == today.getYear();
                default -> true;
            })
            .sorted(Comparator.comparing(HistoryEntry::getDateTime))
            .collect(Collectors.toList());

        if (filtered.isEmpty()) {
            Label empty = new Label(
                "No data for this period.\n" +
                "Complete a voice check-in to see your emotion graph."
            );
            empty.setStyle(
                "-fx-font-size:14px;-fx-text-fill:#8080A0;"
            );
            empty.setLayoutX(40);
            empty.setLayoutY(80);
            graphPane.getChildren().add(empty);
            return;
        }

        double width  = Math.max(graphPane.getWidth(),  600);
        double height = Math.max(graphPane.getHeight(), 300);
        double padL   = 60;
        double padR   = 30;
        double padT   = 30;
        double padB   = 70;
        double chartW = width  - padL - padR;
        double chartH = height - padT - padB;

        // Grid lines and Y labels
        for (int i = 0; i <= 10; i += 2) {
            double y = padT + chartH - (chartH * i / 10.0);
            javafx.scene.shape.Line grid =
                new javafx.scene.shape.Line(
                    padL, y, padL + chartW, y
                );
            grid.setStyle(
                "-fx-stroke:#E8E4E0;-fx-stroke-width:1;"
            );
            Label yLbl = new Label(String.valueOf(i));
            yLbl.setStyle(
                "-fx-font-size:11px;-fx-text-fill:#9090A8;"
            );
            yLbl.setLayoutX(padL - 28);
            yLbl.setLayoutY(y - 8);
            graphPane.getChildren().addAll(grid, yLbl);
        }

        // Y axis title
        Label yTitle = new Label("Stress");
        yTitle.setStyle("-fx-font-size:11px;-fx-text-fill:#9090A8;");
        yTitle.setLayoutX(4);
        yTitle.setLayoutY(padT + chartH / 2 - 10);
        graphPane.getChildren().add(yTitle);

        // Bars
        double barWidth = Math.min(44, (chartW / filtered.size()) - 8);
        double spacing  = chartW / filtered.size();

        for (int i = 0; i < filtered.size(); i++) {
            HistoryEntry entry = filtered.get(i);
            String[] cfg = EMOTION_CONFIG.getOrDefault(
                entry.getEmotion(),
                new String[]{"#505065","chip-gray"}
            );
            double x      = padL + i * spacing + spacing / 2;
            double stress = entry.getStressIndex();
            double barH   = chartH * stress / 10.0;
            double y      = padT + chartH - barH;

            // Bar
            javafx.scene.shape.Rectangle bar =
                new javafx.scene.shape.Rectangle(
                    x - barWidth / 2, y, barWidth, barH
                );
            bar.setArcWidth(6); bar.setArcHeight(6);
            bar.setFill(Color.web(cfg[0]));
            bar.setOpacity(0.85);

            // Emotion label above bar
            Label emoLbl = new Label(entry.getEmotion());
            emoLbl.setStyle(
                "-fx-font-size:10px;-fx-font-weight:bold;" +
                "-fx-text-fill:" + cfg[0] + ";"
            );
            emoLbl.setLayoutX(x - barWidth / 2);
            emoLbl.setLayoutY(y - 18);

            // Date label below
            Label dateLbl = new Label(
                entry.getDateTime().format(
                    DateTimeFormatter.ofPattern("dd/MM\nh:mm")
                )
            );
            dateLbl.setStyle(
                "-fx-font-size:9px;-fx-text-fill:#9090A8;"
            );
            dateLbl.setLayoutX(x - barWidth / 2 - 4);
            dateLbl.setLayoutY(padT + chartH + 6);

            // Dot on top
            javafx.scene.shape.Circle dot =
                new javafx.scene.shape.Circle(x, y, 5);
            dot.setFill(Color.web(cfg[0]));
            dot.setStroke(Color.WHITE);
            dot.setStrokeWidth(2);

            final HistoryEntry clicked = entry;
            final String color = cfg[0];

            bar.setOnMouseClicked(e ->
                showGraphDetail(clicked, color)
            );
            dot.setOnMouseClicked(e ->
                showGraphDetail(clicked, color)
            );
            bar.setOnMouseEntered(e -> bar.setOpacity(1.0));
            bar.setOnMouseExited(e ->  bar.setOpacity(0.85));

            graphPane.getChildren().addAll(
                bar, dot, emoLbl, dateLbl
            );
        }

        // Axes
        javafx.scene.shape.Line xAxis =
            new javafx.scene.shape.Line(
                padL, padT + chartH, padL + chartW, padT + chartH
            );
        xAxis.setStyle("-fx-stroke:#C8C4BC;-fx-stroke-width:1.5;");

        javafx.scene.shape.Line yAxis =
            new javafx.scene.shape.Line(
                padL, padT, padL, padT + chartH
            );
        yAxis.setStyle("-fx-stroke:#C8C4BC;-fx-stroke-width:1.5;");

        graphPane.getChildren().addAll(xAxis, yAxis);
    }

    private void showGraphDetail(HistoryEntry entry, String color) {
        if (graphDetailBox == null) return;
        graphDetailBox.setVisible(true);
        graphDetailDate.setText(entry.getFormattedDateTime());
        graphDetailDate.setStyle(
            "-fx-font-size:12px;-fx-text-fill:#8080A0;"
        );
        graphDetailEmotion.setText(
            entry.getEmotion() + "  " + entry.getConfidence() + "%"
        );
        graphDetailEmotion.setStyle(
            "-fx-font-size:18px;-fx-font-weight:bold;" +
            "-fx-text-fill:" + color + ";"
        );
        graphDetailStress.setText(
            "Stress: " +
            String.format("%.1f", entry.getStressIndex()) + " / 10"
        );
        graphDetailStress.setStyle(
            "-fx-font-size:13px;-fx-text-fill:#606060;"
        );
        graphDetailFeedback.setText(entry.getAiFeedback());
        graphDetailFeedback.setStyle(
            "-fx-font-size:13px;-fx-text-fill:#3A3A52;" +
            "-fx-line-spacing:3;"
        );
    }

    // ── Settings ──────────────────────────────────────────────────
    private void setupSettings() {
        UserSession s = UserSession.getInstance();
        String name = s.getUserName()  != null ? s.getUserName()  : "";
        String id   = s.getPatientId() != null ? s.getPatientId() : "--";

        if (settingsNameField   != null)
            settingsNameField.setText(toTitleCase(name));
        if (settingsUserIdBadge != null)
            settingsUserIdBadge.setText(id);

        if (micSensitivity != null) {
            micSensitivity.getItems().addAll("High","Medium","Low");
            micSensitivity.setValue("Medium");
        }
        if (analysisInterval != null) {
            analysisInterval.getItems().addAll(
                "10 seconds","20 seconds","30 seconds"
            );
            analysisInterval.setValue("20 seconds");
        }
        if (fontSizeCombo != null) {
            fontSizeCombo.getItems().addAll("Small","Medium","Large");
            fontSizeCombo.setValue("Medium");
        }
        if (languageCombo != null) {
            languageCombo.getItems().addAll(
                "English","Tamil","Hindi","Telugu"
            );
            languageCombo.setValue("English");
        }
    }

    @FXML private void onNavSettings() { showPage("settings"); }

    @FXML private void onToggleReminder() {
        toggleButton(toggleReminder);
    }
    @FXML private void onToggleWeekly() {
        toggleButton(toggleWeekly);
    }
    @FXML private void onToggleStressAlert() {
        toggleButton(toggleStressAlert);
    }
    @FXML private void onToggleSaveRecordings() {
        toggleButton(toggleSaveRecordings);
    }

    private void toggleButton(Button btn) {
        boolean isOn = "ON".equals(btn.getText());
        btn.setText(isOn ? "OFF" : "ON");
        btn.getStyleClass().removeAll("toggle-on","toggle-off");
        btn.getStyleClass().add(isOn ? "toggle-off" : "toggle-on");
    }

    @FXML
    private void onSaveDisplayName() {
        if (settingsNameField == null) return;
        String newName = settingsNameField.getText().trim();
        if (newName.isEmpty()) {
            showAlert("Name cannot be empty.");
            return;
        }
        String titled = toTitleCase(newName);
        UserSession.getInstance().setUserName(titled);
        sidebarUserName.setText(titled);
        userNameLabel.setText(titled);
        avatarLabel.setText(UserSession.getInstance().getInitials());
        sidebarAvatarLabel.setText(
            UserSession.getInstance().getInitials()
        );
        showAlert("Display name updated to: " + titled);
    }

    @FXML
    private void onChangePassword() {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Change Password");
        dialog.setHeaderText("Enter your new password");

        PasswordField newPass = new PasswordField();
        newPass.setPromptText("New password (min 6 characters)");
        PasswordField confirm = new PasswordField();
        confirm.setPromptText("Confirm new password");

        VBox content = new VBox(10,
            new Label("New password:"), newPass,
            new Label("Confirm:"), confirm
        );
        content.setPadding(new Insets(10));
        dialog.getDialogPane().setContent(content);
        dialog.getDialogPane().getButtonTypes().addAll(
            ButtonType.OK, ButtonType.CANCEL
        );
        dialog.setResultConverter(btn ->
            btn == ButtonType.OK ? newPass.getText() : null
        );

        dialog.showAndWait().ifPresent(pass -> {
            if (pass.length() < 6)
                showAlert("Password must be at least 6 characters.");
            else if (!pass.equals(confirm.getText()))
                showAlert("Passwords do not match.");
            else
                showAlert("Password changed successfully!");
        });
    }

    @FXML
    private void onExportData() {
        String uid = UserSession.getInstance().getPatientId();
        List<HistoryEntry> userHistory = allHistory.stream()
            .filter(e -> uid != null && uid.equals(e.getOwnerUserId()))
            .collect(Collectors.toList());

        if (userHistory.isEmpty()) {
            showAlert(
                "No data to export yet.\n" +
                "Complete some sessions first."
            );
            return;
        }
        showAlert(
            "Export ready!\n\n" +
            "Total records: " + userHistory.size() + "\n\n" +
            "In the full app this saves to a CSV file."
        );
    }

    @FXML
    private void onClearHistory() {
        String uid = UserSession.getInstance().getPatientId();
        long count = allHistory.stream()
            .filter(e -> uid != null && uid.equals(e.getOwnerUserId()))
            .count();

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Clear all history");
        confirm.setHeaderText("Are you sure?");
        confirm.setContentText(
            "This will permanently delete all " + count +
            " session records. This cannot be undone."
        );
        confirm.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                allHistory.removeIf(
                    e -> uid != null && uid.equals(e.getOwnerUserId())
                );
                refreshHistoryTable();
                buildCalendar();
                showAlert("All your history has been cleared.");
            }
        });
    }

    @FXML
    private void onDeleteAccount() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete account");
        confirm.setHeaderText("Are you absolutely sure?");
        confirm.setContentText(
            "This will permanently delete your account and all data.\n" +
            "This action cannot be undone."
        );
        confirm.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                UserSession.getInstance().clear();
                try {
                    URL fxmlUrl = getClass().getResource(
                        "/com/emohealth/fxml/LoginView.fxml"
                    );
                    FXMLLoader loader = new FXMLLoader(fxmlUrl);
                    Scene scene = new Scene(loader.load(), 500, 700);
                    URL cssUrl = getClass().getResource(
                        "/com/emohealth/css/dark-theme.css"
                    );
                    if (cssUrl != null)
                        scene.getStylesheets().add(
                            cssUrl.toExternalForm()
                        );
                    Stage stage = (Stage) sidebarUserName
                        .getScene().getWindow();
                    stage.setScene(scene);
                    stage.setTitle("EmotionDetection — Sign in");
                    stage.show();
                } catch (Exception e) { e.printStackTrace(); }
            }
        });
    }

    // ── Navigation ────────────────────────────────────────────────
    @FXML private void onNavMonitor()  { showPage("monitor");   }
    @FXML private void onNavHistory()  {
        showPage("history");
        refreshHistoryTable();
    }
    @FXML private void onNavCalendar() {
        showPage("calendar");
        buildCalendar();
    }
    @FXML private void onNavReports()  { showPage("reports");   }

    private void showPage(String page) {
        currentPage = page;

        if (pageMonitor   != null) pageMonitor.setVisible(
            "monitor".equals(page));
        if (pageHistory   != null) pageHistory.setVisible(
            "history".equals(page));
        if (pageCalendar  != null) pageCalendar.setVisible(
            "calendar".equals(page));
        if (pageReports   != null) pageReports.setVisible(
            "reports".equals(page));
        if (pageAiInsight != null) pageAiInsight.setVisible(
            "aiinsight".equals(page));
        if (pageGraph     != null) pageGraph.setVisible(
            "graph".equals(page));
        if (pageSettings  != null) pageSettings.setVisible(
            "settings".equals(page));

        List<HBox> navItems = new ArrayList<>();
        List<String> pages  = new ArrayList<>();

        if (navMonitor   != null) { navItems.add(navMonitor);
            pages.add("monitor"); }
        if (navHistory   != null) { navItems.add(navHistory);
            pages.add("history"); }
        if (navCalendar  != null) { navItems.add(navCalendar);
            pages.add("calendar"); }
        if (navReports   != null) { navItems.add(navReports);
            pages.add("reports"); }
        if (navAiInsight != null) { navItems.add(navAiInsight);
            pages.add("aiinsight"); }
        if (navGraph     != null) { navItems.add(navGraph);
            pages.add("graph"); }
        if (navSettings  != null) { navItems.add(navSettings);
            pages.add("settings"); }

        for (int i = 0; i < navItems.size(); i++) {
            HBox nav    = navItems.get(i);
            boolean act = pages.get(i).equals(page);
            nav.getStyleClass().removeAll("nav-active");
            if (act) nav.getStyleClass().add("nav-active");
            nav.getChildren().stream()
                .filter(n -> n instanceof Label)
                .forEach(n -> {
                    Label l = (Label) n;
                    if (l.getStyleClass().stream()
                            .anyMatch(c -> c.startsWith("nav-label"))) {
                        l.getStyleClass().removeAll(
                            "nav-label-active","nav-label"
                        );
                        l.getStyleClass().add(
                            act ? "nav-label-active" : "nav-label"
                        );
                    }
                });
        }
    }

    @FXML
    private void onLogout() {
        UserSession.getInstance().clear();
        try {
            URL fxmlUrl = getClass().getResource(
                "/com/emohealth/fxml/LoginView.fxml"
            );
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Scene scene = new Scene(loader.load(), 500, 700);
            URL cssUrl = getClass().getResource(
                "/com/emohealth/css/dark-theme.css"
            );
            if (cssUrl != null)
                scene.getStylesheets().add(cssUrl.toExternalForm());
            Stage stage = (Stage) sidebarUserName
                .getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("EmotionDetection — Sign in");
            stage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ── Beautiful dialog ──────────────────────────────────────────
    private void showBeautifulDialog(
            String emotion, String subtitle,
            String color, String feedback,
            String suggestion, String breathing,
            String[] quote, List<String> resources) {

        Stage dialog = new Stage();
        dialog.initModality(
            javafx.stage.Modality.APPLICATION_MODAL
        );
        dialog.setTitle(emotion);

        Label emotionLbl = new Label(emotion);
        emotionLbl.setStyle(
            "-fx-font-size:32px;-fx-font-weight:bold;" +
            "-fx-text-fill:" + color + ";"
        );
        Label subLbl = new Label(subtitle);
        subLbl.setStyle(
            "-fx-font-size:13px;-fx-text-fill:#8080A0;" +
            "-fx-font-weight:bold;"
        );
        VBox header = new VBox(6, emotionLbl, subLbl);
        header.setStyle(
            "-fx-background-color:#F8F7F4;" +
            "-fx-border-color:#E8E4E0;" +
            "-fx-border-width:0 0 1 0;" +
            "-fx-padding:24 28 20 28;"
        );

        VBox feedBox = makeDialogBox(
            "HOW YOU ARE FEELING",
            feedback, "#F8F7F4", "#E8E4E0", "#2A2A42"
        );
        VBox suggBox = makeDialogBox(
            "💡  WHAT YOU CAN DO RIGHT NOW",
            suggestion, "#F0FBF6", "#7DCFAB", "#2A4A3E"
        );
        VBox breathBox = makeDialogBox(
            "🫁  BREATHING EXERCISE",
            breathing, "#F0EEF8", "#C8B8F0", "#2A2060"
        );

        Label qText = new Label(quote[0]);
        qText.setWrapText(true);
        qText.setStyle(
            "-fx-font-size:14px;-fx-font-style:italic;" +
            "-fx-text-fill:#3A2E7A;-fx-line-spacing:3;"
        );
        Label qAuth = new Label(quote[1]);
        qAuth.setStyle(
            "-fx-font-size:12px;-fx-text-fill:#7060B0;" +
            "-fx-font-weight:bold;"
        );
        VBox quoteBox = new VBox(6, qText, qAuth);
        quoteBox.setStyle(
            "-fx-background-color:#F4F0FF;" +
            "-fx-border-color:#B0A0E8;" +
            "-fx-border-width:0 0 0 4;" +
            "-fx-background-radius:0 10px 10px 0;" +
            "-fx-padding:12 16 12 16;"
        );

        Label resTitle = new Label("🔗  MENTAL HEALTH RESOURCES");
        resTitle.setStyle(
            "-fx-font-size:11px;-fx-font-weight:bold;" +
            "-fx-text-fill:#1A3A7A;"
        );
        VBox resItems = new VBox(6);

        Map<String, String> linkMap = new LinkedHashMap<>();
        linkMap.put("icallhelpline","https://icallhelpline.org");
        linkMap.put("nimhansdigital",
            "https://nimhansdigitalacademy.in");
        linkMap.put("nimhans",  "https://nimhans.ac.in");
        linkMap.put("headspace","https://www.headspace.com");
        linkMap.put("calm",     "https://www.calm.com");
        linkMap.put("7 cups",   "https://www.7cups.com");
        linkMap.put("mindshift",
            "https://www.anxietycanada.com/resources/mindshift-cbt");

        for (String r : resources) {
            Label item = new Label("• " + r);
            String rLow = r.toLowerCase();
            String url  = linkMap.entrySet().stream()
                .filter(e -> rLow.contains(e.getKey()))
                .map(Map.Entry::getValue)
                .findFirst().orElse(null);
            if (url != null) {
                final String fu = url;
                item.setStyle(
                    "-fx-font-size:13px;-fx-text-fill:#2355C8;" +
                    "-fx-cursor:hand;-fx-underline:true;"
                );
                item.setOnMouseClicked(e -> {
                    try {
                        new ProcessBuilder(
                            "cmd","/c","start",fu
                        ).start();
                    } catch (Exception ex) {
                        System.err.println(ex.getMessage());
                    }
                });
            } else {
                item.setStyle(
                    "-fx-font-size:13px;-fx-text-fill:#3A3A52;"
                );
            }
            item.setWrapText(true);
            resItems.getChildren().add(item);
        }

        VBox resBox = new VBox(10, resTitle, resItems);
        resBox.setStyle(
            "-fx-background-color:#F0F4FF;" +
            "-fx-border-color:#A0B4E8;-fx-border-width:1;" +
            "-fx-border-radius:10px;-fx-background-radius:10px;" +
            "-fx-padding:14;"
        );

        Button closeBtn = new Button("Close");
        closeBtn.setMaxWidth(Double.MAX_VALUE);
        closeBtn.setStyle(
            "-fx-background-color:#634ED2;-fx-text-fill:white;" +
            "-fx-font-size:14px;-fx-font-weight:bold;" +
            "-fx-border-radius:10px;-fx-background-radius:10px;" +
            "-fx-padding:12 0 12 0;-fx-cursor:hand;" +
            "-fx-border-width:0;"
        );
        closeBtn.setOnAction(e -> dialog.close());

        VBox content = new VBox(14,
            feedBox, suggBox, breathBox,
            quoteBox, resBox, closeBtn
        );
        content.setStyle("-fx-padding:20 28 28 28;");
        content.setPrefWidth(480);

        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.setStyle(
            "-fx-background-color:white;" +
            "-fx-border-width:0;-fx-background:white;"
        );
        scroll.setPrefHeight(520);

        VBox root = new VBox(header, scroll);
        root.setStyle("-fx-background-color:white;");

        Scene scene = new Scene(root, 540, 680);
        URL cssUrl = getClass().getResource(
            "/com/emohealth/css/dark-theme.css"
        );
        if (cssUrl != null)
            scene.getStylesheets().add(cssUrl.toExternalForm());

        dialog.setScene(scene);
        dialog.setResizable(false);
        dialog.show();
    }

    private VBox makeDialogBox(String title, String body,
                                String bg, String border,
                                String textColor) {
        Label t = new Label(title);
        t.setStyle(
            "-fx-font-size:11px;-fx-font-weight:bold;" +
            "-fx-text-fill:" + border + ";"
        );
        Label b = new Label(body);
        b.setWrapText(true);
        b.setStyle(
            "-fx-font-size:14px;-fx-text-fill:" +
            textColor + ";-fx-line-spacing:3;"
        );
        VBox box = new VBox(8, t, b);
        box.setStyle(
            "-fx-background-color:" + bg + ";" +
            "-fx-border-color:" + border + ";-fx-border-width:1;" +
            "-fx-border-radius:10px;-fx-background-radius:10px;" +
            "-fx-padding:14;"
        );
        return box;
    }

    // ── Helpers ───────────────────────────────────────────────────
    private String formatTime(int s) {
        return String.format("%02d:%02d", s / 60, s % 60);
    }

    private String toTitleCase(String input) {
        if (input == null || input.isEmpty()) return input;
        String[] words = input.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                sb.append(Character.toUpperCase(word.charAt(0)));
                if (word.length() > 1)
                    sb.append(word.substring(1).toLowerCase());
                sb.append(" ");
            }
        }
        return sb.toString().trim();
    }

    private void showAlert(String message) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("EmotionDetection");
        a.setHeaderText(null);
        a.setContentText(message);
        a.showAndWait();
    }

    private Map<String, Integer> buildDefaultScores() {
        Map<String, Integer> m = new LinkedHashMap<>();
        m.put("Happy",    0); m.put("Sad",     0);
        m.put("Surprise", 0); m.put("Angry",   0);
        m.put("Fear",     0); m.put("Neutral",  0);
        m.put("Disgust",  0);
        return m;
    }
}
