package com.emohealth.config;

// ── CHANGE THESE TO YOUR GMAIL ──────────────────
// You need a Gmail App Password (not your normal password)
// Go to: myaccount.google.com → Security → 2-Step Verification
// → App passwords → Create one for "Mail" → copy the 16-char password

public class EmailConfig {
    public static final String SMTP_HOST     = "smtp.gmail.com";
    public static final String SMTP_PORT     = "587";
    public static final String SENDER_EMAIL  = "kowshikavijayanalamelu@gmail.com";
    public static final String SENDER_PASSWORD = "xidz qqqn hmgg jvns";
    public static final String APP_NAME = "EmotionDetection";
}