package com.emohealth.config;

public class GoogleAuthConfig {

    // Paste your values from Google Cloud Console here
    public static final String CLIENT_ID =
        "691837900975-8lhe466k3mb3him3cd42ekhsnghtej79.apps.googleusercontent.com";

    public static final String CLIENT_SECRET =
        "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";

    public static final String REDIRECT_URI =
        "http://localhost:8888";

    public static final String AUTH_URL =
        "https://accounts.google.com/o/oauth2/auth";

    public static final String TOKEN_URL =
        "https://oauth2.googleapis.com/token";

    public static final String USER_INFO_URL =
        "https://www.googleapis.com/oauth2/v3/userinfo";

    public static final String SCOPE =
        "openid email profile";
}