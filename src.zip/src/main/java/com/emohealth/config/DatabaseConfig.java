package com.emohealth.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConfig {

    // ── CHANGE THESE TO MATCH YOUR MYSQL SETUP ──
    private static final String URL      = "jdbc:mysql://localhost:3306/emohealth_db";
    private static final String USER     = "root";
    private static final String PASSWORD = "root123";
    // ─────────────────────────────────────────────

    private static Connection connection;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("MySQL connected successfully!");
            } catch (ClassNotFoundException e) {
                throw new SQLException("MySQL driver not found: " + e.getMessage());
            }
        }
        return connection;
    }

    public static boolean testConnection() {
        try {
            getConnection();
            return true;
        } catch (SQLException e) {
            System.err.println("MySQL connection failed: " + e.getMessage());
            return false;
        }
    }
}