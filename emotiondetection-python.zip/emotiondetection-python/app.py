from flask import Flask, request, jsonify
import numpy as np
import librosa
import soundfile as sf
import io
import os
import tempfile
from tensorflow.keras.models import load_model

app = Flask(__name__)

# ── Load your trained model ────────────────────
MODEL_PATH = r"D:\emotiondetection-python\combined_final1.h5"

print("Loading emotion model...")
try:
    emotion_model = load_model(MODEL_PATH)
    print("Model loaded successfully!")
except Exception as e:
    print(f"Model load error: {e}")
    emotion_model = None

# ── Emotion labels matching your training ──────
EMOTION_LABELS = [
    "Neutral", "Happy", "Sad",
    "Angry",   "Fear",  "Disgust", "Surprise"
]

# ── Stress index per emotion ───────────────────
STRESS_MAP = {
    "Angry":   8.5,
    "Fear":    7.8,
    "Disgust": 6.5,
    "Sad":     5.5,
    "Surprise":4.0,
    "Neutral": 3.0,
    "Happy":   2.0
}

# ── Feature extraction ─────────────────────────
def extract_features(audio_data, sample_rate):
    try:
        mfcc = np.mean(
            librosa.feature.mfcc(
                y=audio_data,
                sr=sample_rate,
                n_mfcc=40
            ).T,
            axis=0
        )
        return mfcc
    except Exception as e:
        print(f"Feature extraction error: {e}")
        return None

# ── Silence check ──────────────────────────────
def is_silent(audio):
    energy = np.mean(np.abs(audio))
    return energy < 0.01

# ── Predict emotion ────────────────────────────
def predict_emotion(audio_bytes):
    try:
        # Save bytes to temp file
        with tempfile.NamedTemporaryFile(
            suffix='.wav', delete=False
        ) as tmp:
            tmp.write(audio_bytes)
            tmp_path = tmp.name

        # Load audio
        audio_data, sample_rate = librosa.load(
            tmp_path,
            duration=2.5,
            offset=0.6,
            sr=16000
        )
        os.unlink(tmp_path)

        # Check silence
        if is_silent(audio_data):
            print("Silent audio detected")
            return simulate_result()

        # Extract features
        features = extract_features(audio_data, sample_rate)
        if features is None:
            return simulate_result()

        # Reshape for CNN+BiLSTM: (1, 40, 1)
        features = np.expand_dims(features, axis=0)
        features = np.expand_dims(features, axis=2)

        # Predict
        prediction = emotion_model.predict(features, verbose=0)
        index      = np.argmax(prediction)
        confidence = float(np.max(prediction)) * 100

        emotion    = EMOTION_LABELS[index]
        stress     = calculate_stress(emotion, confidence)

        # Build scores for all emotions
        scores = {}
        for i, label in enumerate(EMOTION_LABELS):
            scores[label] = int(prediction[0][i] * 100)

        print(f"Predicted: {emotion} ({confidence:.1f}%)")

        return {
            "dominantEmotion": emotion,
            "confidence":      int(confidence),
            "stressIndex":     round(stress, 1),
            "scores":          scores,
            "insight": (
                f"Voice analysis complete. "
                f"Detected {emotion} with "
                f"{int(confidence)}% confidence."
            ),
            "tags": build_tags(emotion, stress)
        }

    except Exception as e:
        print(f"Prediction error: {e}")
        return simulate_result()

# ── Calculate stress ───────────────────────────
def calculate_stress(emotion, confidence):
    base   = STRESS_MAP.get(emotion, 5.0)
    adjust = (confidence / 100.0) * 1.5
    return min(10.0, max(0.0, base + adjust - 0.75))

# ── Build tags ─────────────────────────────────
def build_tags(emotion, stress):
    tags = [f"{emotion} detected"]
    if stress > 6:
        tags.append("High stress")
    if stress > 4:
        tags.append("Monitor closely")
    if emotion in ["Happy"]:
        tags.append("Positive state")
    return tags

# ── Simulate result when model unavailable ─────
def simulate_result():
    import random
    emotion = random.choice(EMOTION_LABELS)
    scores  = {}
    probs   = [random.random() for _ in EMOTION_LABELS]
    total   = sum(probs)
    for i, e in enumerate(EMOTION_LABELS):
        scores[e] = int(probs[i] / total * 100)
    stress = calculate_stress(emotion, 80)
    return {
        "dominantEmotion": emotion,
        "confidence":      random.randint(70, 95),
        "stressIndex":     round(stress, 1),
        "scores":          scores,
        "insight":         "Simulated result for testing",
        "tags":            build_tags(emotion, stress)
    }

# ── API Routes ─────────────────────────────────
@app.route('/predict', methods=['POST'])
def predict():
    try:
        audio_bytes = request.data
        user_id     = request.headers.get('User-Id', 'unknown')

        print(f"Request from user: {user_id}, "
              f"audio size: {len(audio_bytes)} bytes")

        if len(audio_bytes) == 0:
            return jsonify(simulate_result()), 200

        if emotion_model is None:
            return jsonify(simulate_result()), 200

        result = predict_emotion(audio_bytes)
        return jsonify(result), 200

    except Exception as e:
        print(f"Route error: {e}")
        return jsonify(simulate_result()), 200

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        "status":       "running",
        "model_loaded": emotion_model is not None,
        "emotions":     EMOTION_LABELS
    }), 200

# ── Start server ───────────────────────────────
if __name__ == '__main__':
    print("=" * 40)
    print("EmotionDetection Python API")
    print("Running on http://localhost:5000")
    print("=" * 40)
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=False
    )