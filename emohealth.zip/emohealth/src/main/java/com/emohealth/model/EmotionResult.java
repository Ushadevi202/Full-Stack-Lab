package com.emohealth.model;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class EmotionResult {

    private String dominantEmotion;
    private int topConfidence;
    private double stressIndex;
    private Map<String, Integer> scores;
    private String aiInsight;
    private List<String> tags;
    private LocalDateTime timestamp;

    public EmotionResult() {
        this.timestamp = LocalDateTime.now();
        this.scores = new LinkedHashMap<>();
    }

    // ── Builder-style factory ──────────────────────────────────────
    public static EmotionResult simulate() {
        EmotionResult r = new EmotionResult();
        java.util.Random rng = new java.util.Random();

        String[] emotions  = {"Anxious", "Sad", "Neutral", "Angry", "Happy", "Surprise"};
        int[]    baseScores = {87, 42, 30, 18, 9, 5};

        // Shuffle to simulate variation
        int shift = rng.nextInt(emotions.length);
        for (int i = 0; i < emotions.length; i++) {
            int idx   = (i + shift) % emotions.length;
            int score = Math.max(0, Math.min(100,
                baseScores[idx] + rng.nextInt(20) - 10));
            r.scores.put(emotions[i], score);
        }

        // Find dominant
        r.dominantEmotion = r.scores.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey)
            .orElse("Neutral");
        r.topConfidence = r.scores.get(r.dominantEmotion);
        r.stressIndex   = 3.0 + rng.nextDouble() * 6.0;

        r.aiInsight = buildInsight(r.dominantEmotion, r.stressIndex);
        r.tags      = buildTags(r.dominantEmotion, r.stressIndex);

        return r;
    }

    private static String buildInsight(String emotion, double stress) {
        return switch (emotion) {
            case "Anxious" ->
                "Patient shows elevated anxiety. Voice pitch variance is 18% above " +
                "personal baseline. Recommend calming techniques before proceeding.";
            case "Sad" ->
                "Persistent sadness detected. Low energy vocal patterns with reduced " +
                "speech rate. Consider supportive counselling intervention.";
            case "Angry" ->
                "Heightened arousal and frustration detected. Vocal intensity is " +
                "elevated. Allow patient time to settle before continuing session.";
            case "Happy" ->
                "Positive emotional state detected. Patient is engaged and responsive. " +
                "Good time to introduce therapy goals or new exercises.";
            default ->
                String.format("Stress index: %.1f/10. Overall emotional state is %s. " +
                "Continue monitoring and log any notable changes.", stress, emotion.toLowerCase());
        };
    }

    private static List<String> buildTags(String emotion, double stress) {
        List<String> tags = new java.util.ArrayList<>();
        if (stress > 6)     tags.add("High stress");
        if (stress > 4)     tags.add("Monitor closely");
        if ("Anxious".equals(emotion) || "Angry".equals(emotion)) tags.add("Breathing exercise");
        if ("Sad".equals(emotion))                                 tags.add("Supportive care");
        if ("Happy".equals(emotion))                               tags.add("Positive state");
        if (tags.isEmpty()) tags.add("Stable");
        return tags;
    }

    // ── Getters & Setters ──────────────────────────────────────────
    public String getDominantEmotion() { return dominantEmotion; }
    public void setDominantEmotion(String dominantEmotion) { this.dominantEmotion = dominantEmotion; }

    public int getTopConfidence() { return topConfidence; }
    public void setTopConfidence(int topConfidence) { this.topConfidence = topConfidence; }

    public double getStressIndex() { return stressIndex; }
    public void setStressIndex(double stressIndex) { this.stressIndex = stressIndex; }

    public Map<String, Integer> getScores() { return scores; }
    public void setScores(Map<String, Integer> scores) { this.scores = scores; }

    public String getAiInsight() { return aiInsight; }
    public void setAiInsight(String aiInsight) { this.aiInsight = aiInsight; }

    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
